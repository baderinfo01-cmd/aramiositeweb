<?php
require_once 'includes/init.php';
$lang = $_SESSION['lang'];

$t = [
    'home' => ($lang == 'ar') ? 'الرئيسية' : 'Home', 'about' => ($lang == 'ar') ? 'من نحن' : 'About Us', 'courses' => ($lang == 'ar') ? 'الدورات' : 'Courses', 'trainers' => ($lang == 'ar') ? 'المدربين' : 'Trainers', 'verify' => ($lang == 'ar') ? 'الشهادات' : 'Verify', 'contact' => ($lang == 'ar') ? 'تواصل معنا' : 'Contact Us', 'login' => ($lang == 'ar') ? 'دخول' : 'Login', 'register' => ($lang == 'ar') ? 'حساب جديد' : 'Sign Up', 'dashboard' => ($lang == 'ar') ? 'لوحة التحكم' : 'Dashboard',
    'about_title' => ($lang == 'ar') ? 'نصنع الفرق… لأننا نؤمن بالإنسان' : 'We Make a Difference... Because We Believe in Humanity',
    'about_desc' => ($lang == 'ar') ? 'منارة التمكين والتطوير الإنساني عالمياً، نُعيد تأهيل الإنسان فكرياً ومهنياً ليقود نفسه ومحيطه باحتراف ووعي.' : 'A global beacon of empowerment and human development. We rehabilitate individuals intellectually and professionally to lead themselves and their surroundings with professionalism and awareness.',
    'dr_title' => ($lang == 'ar') ? 'الدكتورة صبيرة حركات' : 'Dr. Sabira Harakat',
    'dr_role' => ($lang == 'ar') ? 'المؤسس ورئيس مجلس الإدارة' : 'Founder & Chairman of the Board',
    'dr_bio' => ($lang == 'ar') ? 'رائدة أعمال، مستشارة أسرية معتمدة، مدربة حياة دولية ومدربة مدربين دولية معتمدة. خبيرة في إعداد وتكوين المدربين والمستشارين والمعالجين والأخصائيين. تتمتع بخبرة مهنية واسعة تمتد لأكثر من <strong>15 سنة</strong>.' : 'Entrepreneur, Certified Family Counselor, International Life Coach, and Certified International Master Trainer. Expert in preparing and training consultants and therapists, with over <strong>15 years</strong> of professional experience.',
    'dr_quote' => ($lang == 'ar') ? '"أشرفنا على تنظيم وإدارة العديد من الملتقيات الدولية المعتمدة، وأسهمنا في تخريج آلاف المتدربين من مختلف الجنسيات عبر برامج مهنية تشمل الماجستير والدكتوراه الفخرية."' : '"We have supervised and managed numerous accredited international forums, contributing to the graduation of thousands of trainees worldwide through professional programs including Master\'s and Honorary Doctorates."',
    'dr_certs' => ($lang == 'ar') ? 'اعتمادات الإدارة العليا:' : 'Top Management Accreditations:',
    'cert_1' => ($lang == 'ar') ? 'معتمدة من SMART Global University.' : 'Accredited by SMART Global University.',
    'cert_2' => ($lang == 'ar') ? 'معتمدة من جامعة صفانة الأكاديمية.' : 'Accredited by Safana Academic University.',
    'val_title' => ($lang == 'ar') ? 'قيمنا الجوهرية' : 'Our Core Values',
    'v1' => ($lang == 'ar') ? 'الاحترافية' : 'Professionalism', 'v1_sub' => ($lang == 'ar') ? 'في المحتوى والتقديم' : 'In content and delivery',
    'v2' => ($lang == 'ar') ? 'التمكين' : 'Empowerment', 'v2_sub' => ($lang == 'ar') ? 'إيماننا بقدرة الفرد' : 'Belief in individual potential',
    'v3' => ($lang == 'ar') ? 'الإنسانية' : 'Humanity', 'v3_sub' => ($lang == 'ar') ? 'مراعاة الأبعاد النفسية' : 'Considering psychological dimensions',
    'v4' => ($lang == 'ar') ? 'الجودة' : 'Quality', 'v4_sub' => ($lang == 'ar') ? 'معايير دقيقة لا تساوم' : 'Strict uncompromising standards',
    'v5' => ($lang == 'ar') ? 'العالمية' : 'Global Reach', 'v5_sub' => ($lang == 'ar') ? 'اعتراف وتوثيق دولي' : 'International recognition',
    'prog_title' => ($lang == 'ar') ? 'برامجنا – صناعة التميز من الجذور' : 'Our Programs – Crafting Excellence from the Roots',
    'prog_desc' => ($lang == 'ar') ? 'نحن لا نقدّم مجرد دورات… بل نُعيد تعريف التعلّم ونبني جسوراً بين العلم والمهارة.' : 'We don\'t just offer courses... we redefine learning and build bridges between knowledge and skill.',
    'p1' => ($lang == 'ar') ? 'دورات الطب البديل والعلاج التكميلي' : 'Alternative Medicine & Complementary Therapy',
    'p2' => ($lang == 'ar') ? 'دورات التجميل والعناية الطبيعية' : 'Cosmetics & Natural Care Courses',
    'p3' => ($lang == 'ar') ? 'البرامج التربوية والطفولة المبكرة' : 'Educational Programs & Early Childhood',
    'p4' => ($lang == 'ar') ? 'الدورات القيادية والاعتمادات الدولية' : 'Leadership Courses & International Accreditations',
    'p5' => ($lang == 'ar') ? 'دورات الوعي وتطوير الذات' : 'Awareness & Self-Development Courses',
    'spec_title' => ($lang == 'ar') ? 'جميع التخصصات المتاحة' : 'All Available Specialties',
    'btn_start' => ($lang == 'ar') ? 'تصفح الدورات وسجل الآن' : 'Browse Courses & Register Now',
    'gallery_title' => ($lang == 'ar') ? 'معرض الصور الميدانية' : 'Field Gallery',
    'reviews_gallery_title' => ($lang == 'ar') ? 'آراء وتقييمات لخدماتنا' : 'Reviews & Feedback'
];

$contact_email = getSetting($pdo, 'contact_email', $lang) ?: 'info@aramio.com'; 
$contact_phone = getSetting($pdo, 'phone_number', $lang) ?: '+000000000';
$fb_link = getSetting($pdo, 'facebook_link') ?: '#'; $tw_link = getSetting($pdo, 'twitter_link') ?: '#'; $ig_link = getSetting($pdo, 'instagram_link') ?: '#'; $yt_link = getSetting($pdo, 'youtube_link') ?: '#';

// جلب صور المعرضين
$db_gallery = $pdo->query("SELECT image_name FROM gallery_images WHERE image_type = 'gallery' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_COLUMN);
$db_reviews = $pdo->query("SELECT image_name FROM gallery_images WHERE image_type = 'review' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html><html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title><?php echo htmlspecialchars($siteName); ?> | <?php echo $t['about']; ?></title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.<?php echo ($lang=='ar')?'rtl.':''; ?>min.css"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" /><style>:root { --primary: #0b1c3f; --accent: #1cc88a; --bg-light: #f4f7f6; } html, body { max-width: 100vw; overflow-x: hidden; font-family: 'Cairo', sans-serif; background: #fff; } .navbar-custom { background: var(--primary); padding: 10px 0; box-shadow: 0 4px 10px rgba(0,0,0,0.1); } .nav-link { color: #fff !important; font-weight: 600; } .btn-outline { border: 1px solid #fff; color: #fff; border-radius: 30px; padding: 5px 20px; text-decoration: none; font-size: 0.9rem;} .btn-solid { background: var(--accent); color: #fff; border-radius: 30px; padding: 6px 20px; text-decoration: none; font-weight: bold; border: none; } .about-header { background: linear-gradient(135deg, var(--primary) 0%, #1a3673 100%); padding: 120px 0 80px; color: white; text-align: center; position: relative; overflow: hidden; border-bottom: 5px solid var(--accent); } .ceo-section { background: #fff; padding: 80px 0; } .ceo-img-wrap { position: relative; z-index: 1; } .ceo-img { width: 100%; max-width: 350px; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); border: 8px solid #fff; } .ceo-backdrop { position: absolute; top: -20px; <?php echo ($lang=='ar')?'right':'left'; ?>: -20px; width: 100%; height: 100%; background: var(--accent); border-radius: 20px; z-index: -1; opacity: 0.2; } .value-card { background: #f8f9fc; padding: 30px 20px; border-radius: 15px; text-align: center; transition: 0.3s; height: 100%; border: 1px solid #eee; } .value-card:hover { background: #fff; box-shadow: 0 10px 30px rgba(0,0,0,0.08); transform: translateY(-5px); border-color: var(--accent); } .value-icon { font-size: 2.5rem; color: var(--accent); margin-bottom: 15px; } .programs-section { background: var(--primary); padding: 80px 0; color: white; } .accordion-button { font-weight: bold; font-family: 'Cairo'; font-size: 1.1rem; padding: 20px; } .accordion-button:not(.collapsed) { color: var(--primary); background-color: #e8f9f2; box-shadow: none; } .accordion-button:focus { box-shadow: none; border-color: rgba(0,0,0,.125); } .accordion-body { background: #fff; color: #333; line-height: 1.8; padding: 25px; } .specialty-badge { background: rgba(11, 28, 63, 0.05); color: var(--primary); border: 1px solid rgba(11, 28, 63, 0.1); font-weight: bold; padding: 10px 20px; border-radius: 30px; margin: 5px; display: inline-block; transition: 0.3s; cursor: default; } .specialty-badge:hover { background: var(--primary); color: white; } .swiper-button-next, .swiper-button-prev { color: var(--accent) !important; background: white; width: 40px; height: 40px; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.1); } .swiper-button-next:after, .swiper-button-prev:after { font-size: 1.2rem !important; font-weight: bold; }</style></head><body>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top"><div class="container"><a class="navbar-brand d-flex align-items-center" href="index.php"><img src="assets/logo-desktop.png" class="d-none d-md-block" style="height: 60px;" alt="Logo" onerror="this.style.display='none'"><img src="assets/logo-mobile.png" class="d-block d-md-none" style="height: 40px;" alt="Logo" onerror="this.style.display='none'"></a><button class="navbar-toggler border-0 p-1" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon" style="width: 1.5em; height: 1.5em;"></span></button><div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav me-auto mb-2 mb-lg-0 <?php echo ($lang == 'en') ? 'ms-auto me-0' : ''; ?>"><li class="nav-item"><a class="nav-link" href="index.php"><?php echo $t['home']; ?></a></li><li class="nav-item"><a class="nav-link active" href="about.php"><?php echo $t['about']; ?></a></li><li class="nav-item"><a class="nav-link" href="index.php#courses"><?php echo $t['courses']; ?></a></li><li class="nav-item"><a class="nav-link" href="index.php#trainers"><?php echo $t['trainers']; ?></a></li><li class="nav-item"><a class="nav-link" href="index.php#verify"><?php echo $t['verify']; ?></a></li><li class="nav-item"><a class="nav-link text-warning" href="contact.php"><?php echo $t['contact']; ?></a></li></ul><div class="d-flex align-items-center gap-2 mt-2 mt-lg-0 pb-3 pb-lg-0"><a href="?lang=<?php echo ($lang == 'ar') ? 'en' : 'ar'; ?>" class="text-white fw-bold me-2 text-decoration-none"><i class="fa-solid fa-globe"></i> <?php echo ($lang == 'ar') ? 'EN' : 'عربي'; ?></a><?php if(isset($_SESSION['user_id'])): ?><a href="login.php" class="btn-solid"><?php echo $t['dashboard']; ?></a><?php else: ?><a href="login.php" class="btn-outline"><?php echo $t['login']; ?></a><a href="register.php" class="btn-solid"><?php echo $t['register']; ?></a><?php endif; ?></div></div></div></nav>

    <header class="about-header"><div class="container position-relative" style="z-index: 2;"><div class="badge bg-white text-primary rounded-pill px-4 py-2 fw-bold mb-3 fs-6"><i class="fa-solid fa-earth-americas text-accent"></i> ARAMIO SMART GLOBAL ACADEMY</div><h1 class="display-4 fw-black mb-3"><?php echo $t['about_title']; ?></h1><p class="lead w-75 mx-auto opacity-75"><?php echo $t['about_desc']; ?></p></div></header>

    <section class="ceo-section"><div class="container"><div class="row align-items-center g-5"><div class="col-lg-4 text-center"><div class="ceo-img-wrap d-inline-block"><div class="ceo-backdrop"></div><img src="https://aramiosmartglobal.com/uploads/1.jpg
" class="ceo-img" alt="Dr. Sabira"></div></div><div class="col-lg-8"><h6 class="text-accent fw-bold mb-2"><?php echo $t['dr_role']; ?></h6><h2 class="fw-bold mb-4" style="color: var(--primary);"><?php echo $t['dr_title']; ?></h2><p class="text-muted lh-lg mb-4 fs-6"><?php echo $t['dr_bio']; ?></p><div class="bg-light p-4 rounded-4 border-<?php echo ($lang=='ar')?'start':'end'; ?> border-4 border-primary"><p class="m-0 fst-italic text-dark fw-bold"><?php echo $t['dr_quote']; ?></p></div><div class="mt-4 pt-3 border-top"><h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-certificate text-warning <?php echo ($lang=='ar')?'me-2':'ms-2'; ?>"></i> <?php echo $t['dr_certs']; ?></h6><ul class="list-unstyled text-muted small lh-lg"><li><i class="fa-solid fa-check text-success <?php echo ($lang=='ar')?'me-2':'ms-2'; ?>"></i> <?php echo $t['cert_1']; ?></li><li><i class="fa-solid fa-check text-success <?php echo ($lang=='ar')?'me-2':'ms-2'; ?>"></i> <?php echo $t['cert_2']; ?></li></ul></div></div></div></div></section>

    <section class="py-5 bg-light"><div class="container py-5"><div class="text-center mb-5"><h2 class="fw-bold" style="color: var(--primary);"><?php echo $t['val_title']; ?></h2><div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div></div><div class="row g-4 justify-content-center">
        <div class="col-lg-2 col-md-4 col-6"><div class="value-card"><i class="fa-solid fa-star value-icon"></i><h5 class="fw-bold text-dark"><?php echo $t['v1']; ?></h5><small class="text-muted"><?php echo $t['v1_sub']; ?></small></div></div>
        <div class="col-lg-2 col-md-4 col-6"><div class="value-card"><i class="fa-solid fa-rocket value-icon"></i><h5 class="fw-bold text-dark"><?php echo $t['v2']; ?></h5><small class="text-muted"><?php echo $t['v2_sub']; ?></small></div></div>
        <div class="col-lg-2 col-md-4 col-6"><div class="value-card"><i class="fa-solid fa-hands-holding-child value-icon"></i><h5 class="fw-bold text-dark"><?php echo $t['v3']; ?></h5><small class="text-muted"><?php echo $t['v3_sub']; ?></small></div></div>
        <div class="col-lg-2 col-md-4 col-6"><div class="value-card"><i class="fa-solid fa-gem value-icon"></i><h5 class="fw-bold text-dark"><?php echo $t['v4']; ?></h5><small class="text-muted"><?php echo $t['v4_sub']; ?></small></div></div>
        <div class="col-lg-2 col-md-4 col-6"><div class="value-card"><i class="fa-solid fa-globe value-icon"></i><h5 class="fw-bold text-dark"><?php echo $t['v5']; ?></h5><small class="text-muted"><?php echo $t['v5_sub']; ?></small></div></div>
    </div></div></section>

    <section class="programs-section"><div class="container"><div class="text-center mb-5"><h2 class="fw-bold text-white"><?php echo $t['prog_title']; ?></h2><p class="opacity-75"><?php echo $t['prog_desc']; ?></p></div><div class="row justify-content-center"><div class="col-lg-10"><div class="accordion shadow-lg" id="programsAccordion">
        <div class="accordion-item border-0 mb-3 rounded-4 overflow-hidden"><h2 class="accordion-header"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#col1"><i class="fa-solid fa-leaf text-success fs-4 mx-3"></i> <?php echo $t['p1']; ?></button></h2><div id="col1" class="accordion-collapse collapse show" data-bs-parent="#programsAccordion"><div class="accordion-body">
            <ul class="row fw-bold text-dark list-unstyled mb-0">
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> الحجامة التشخيصية والعلاجية</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> التدليك العلاجي وتقنيات الاسترخاء</li>
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> شمع الهوبي وتنظيف الأذن بالطاقة</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> الإبر الصينية والمسارات الطاقية</li>
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> الموكسا (الحرارة الشافية)</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> العلاج بسم النحل</li>
            </ul>
        </div></div></div>
        <div class="accordion-item border-0 mb-3 rounded-4 overflow-hidden"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col2"><i class="fa-solid fa-spa text-warning fs-4 mx-3"></i> <?php echo $t['p2']; ?></button></h2><div id="col2" class="accordion-collapse collapse" data-bs-parent="#programsAccordion"><div class="accordion-body">
            <ul class="row fw-bold text-dark list-unstyled mb-0">
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> التجميل الكلاسيكي والعناية بالبشرة</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> التجميل اللاجراحي والتقنيات الحديثة</li>
                <li class="col-12 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> صناعة مواد التجميل الطبيعية منزليًا ومهنيًا</li>
            </ul>
        </div></div></div>
        <div class="accordion-item border-0 mb-3 rounded-4 overflow-hidden"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col3"><i class="fa-solid fa-child-reaching text-info fs-4 mx-3"></i> <?php echo $t['p3']; ?></button></h2><div id="col3" class="accordion-collapse collapse" data-bs-parent="#programsAccordion"><div class="accordion-body">
            <ul class="row fw-bold text-dark list-unstyled mb-0">
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> دورة مربية أطفال محترفة</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> مسيرة رياض أطفال (مديرة حضانة)</li>
                <li class="col-12 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> منهج المنتسوري من التأسيس إلى التطبيق</li>
            </ul>
        </div></div></div>
        <div class="accordion-item border-0 mb-3 rounded-4 overflow-hidden"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col4"><i class="fa-solid fa-medal text-danger fs-4 mx-3"></i> <?php echo $t['p4']; ?></button></h2><div id="col4" class="accordion-collapse collapse" data-bs-parent="#programsAccordion"><div class="accordion-body">
            <ul class="row fw-bold text-dark list-unstyled mb-0">
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> الخبير الدولي المعتمد</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> المستشار الدولي المعتمد</li>
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> المدرب الدولي المعتمد (CIT)</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> الدكتوراه الفخرية المهنية</li>
                <li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> الماجستير المهني القيادي</li><li class="col-md-6 mb-2"><i class="fa-solid fa-check text-accent mx-2"></i> دبلوم إعداد المستشار الأسري</li>
            </ul>
        </div></div></div>
        <div class="accordion-item border-0 rounded-4 overflow-hidden"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#col5"><i class="fa-solid fa-brain text-primary fs-4 mx-3"></i> <?php echo $t['p5']; ?></button></h2><div id="col5" class="accordion-collapse collapse" data-bs-parent="#programsAccordion"><div class="accordion-body">
            <ul class="list-unstyled fw-bold text-dark lh-lg mb-0">
                <li class="mb-3 border-bottom pb-2"><i class="fa-solid fa-fan text-accent mx-2"></i> <strong>اختاري نفسك وازهري معي:</strong> تفعيل الطاقة الأنثوية برقي وتوازن.</li>
                <li class="mb-3 border-bottom pb-2"><i class="fa-solid fa-fan text-accent mx-2"></i> <strong>أي بُنيّتي... توصيات لحياة ناعمة:</strong> للفتيات من سن 12 لبناء وعي متوازن.</li>
                <li class="mb-3 border-bottom pb-2"><i class="fa-solid fa-fan text-accent mx-2"></i> <strong>اسأل تُعطى... لا مستحيل مع الله:</strong> برنامج إيماني تحويلي للنية والدعاء.</li>
                <li><i class="fa-solid fa-fan text-accent mx-2"></i> <strong>حين تنطق الندوب:</strong> التشافي من جروح الطفولة وبناء اتزان نفسي.</li>
            </ul>
        </div></div></div>
    </div></div></div></div></section>

    <section class="py-5 bg-white"><div class="container text-center"><h3 class="fw-bold mb-4" style="color: var(--primary);"><i class="fa-solid fa-layer-group mx-2"></i> <?php echo $t['spec_title']; ?></h3>
        <div class="d-flex flex-wrap justify-content-center">
            <span class="specialty-badge">التغذية المتوازنة</span><span class="specialty-badge">التسويق الإلكتروني</span><span class="specialty-badge">التأهيل الحركي</span><span class="specialty-badge">الطب البديل</span><span class="specialty-badge">الطب الصيني</span><span class="specialty-badge">العلوم الاستشارية</span><span class="specialty-badge">الطفولة المبكرة</span><span class="specialty-badge">استشارات الأعمال</span><span class="specialty-badge">الدراسات الإسلامية</span><span class="specialty-badge">علم النفس</span><span class="specialty-badge">العلاقات العامة</span><span class="specialty-badge">الموارد البشرية</span><span class="specialty-badge">الطب التجميلي</span><span class="specialty-badge">إدارة الأعمال</span>
        </div>
        <div class="mt-5"><a href="index.php#courses" class="btn btn-accent btn-lg rounded-pill px-5 fw-bold shadow-sm"><?php echo $t['btn_start']; ?> <i class="fa-solid fa-arrow-<?php echo ($lang=='ar')?'left':'right'; ?> mx-2"></i></a></div>
    </div></section>

    <!-- 💡 معرض صور التقييمات في صفحة من نحن -->
    <?php if(!empty($db_reviews)): ?>
    <section class="py-5" style="background: var(--bg-light); border-top: 1px solid #eee;">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold" style="color: var(--primary);"><i class="fa-solid fa-comment-dots text-warning"></i> <?php echo $t['reviews_gallery_title']; ?></h2>
                <div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
            </div>
            <div class="swiper reviewsSwiper px-4 pb-4">
                <div class="swiper-wrapper">
                    <?php foreach($db_reviews as $img): ?>
                    <div class="swiper-slide text-center">
                        <img src="uploads/reviews/<?php echo $img; ?>" class="img-fluid rounded-4 shadow-sm border" style="max-height: 400px; object-fit: contain; background: #fff; width: 100%;" alt="Review">
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 💡 معرض الصور الميدانية في صفحة من نحن -->
    <?php if(!empty($db_gallery)): ?>
    <section class="py-5 bg-white border-top">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold" style="color: var(--primary);"><i class="fa-solid fa-camera text-primary"></i> <?php echo $t['gallery_title']; ?></h2>
                <div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
            </div>
            <div class="swiper gallerySwiper px-4">
                <div class="swiper-wrapper">
                    <?php foreach($db_gallery as $img): ?>
                    <div class="swiper-slide">
                        <img src="uploads/gallery/<?php echo $img; ?>" class="img-fluid rounded-4 shadow-sm" style="height: 250px; object-fit: cover; width: 100%; border: 3px solid #fff;" alt="Gallery Image" loading="lazy">
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <footer class="pt-5 pb-3 text-center text-md-start <?php echo ($lang == 'en') ? 'text-start' : ''; ?>" style="background: var(--primary); color: white; border-top: 4px solid var(--accent);"><div class="container"><div class="row g-4 mb-4"><div class="col-md-5"><h4 class="fw-bold mb-3"><i class="fa-solid fa-graduation-cap mx-2"></i> <?php echo htmlspecialchars($siteName); ?></h4><p class="small opacity-75 lh-lg pe-md-4"><?php echo $t['about_desc']; ?></p><div class="d-flex gap-3 mt-3 justify-content-center justify-content-md-start"><a href="<?php echo htmlspecialchars($fb_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-facebook"></i></a><a href="<?php echo htmlspecialchars($yt_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-youtube text-danger"></i></a><a href="<?php echo htmlspecialchars($ig_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-instagram"></i></a></div></div><div class="col-md-3"><h6 class="fw-bold mb-3 text-warning"><?php echo $t['quick_links']; ?></h6><ul class="list-unstyled small opacity-75 lh-lg"><li><a href="index.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['home']; ?></a></li><li><a href="index.php#courses" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['courses']; ?></a></li><li><a href="index.php#verify" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['verify']; ?></a></li></ul></div><div class="col-md-4"><h6 class="fw-bold mb-3 text-warning"><?php echo $t['contact_us']; ?></h6><p class="small opacity-75 mb-2" dir="ltr"><i class="fa-solid fa-envelope text-accent mx-2"></i> <?php echo htmlspecialchars($contact_email); ?></p><p class="small opacity-75 mb-0" dir="ltr"><i class="fa-solid fa-phone text-accent mx-2"></i> <span dir="ltr"><?php echo htmlspecialchars($contact_phone); ?></span></p></div></div><div class="border-top border-light border-opacity-10 pt-3 mt-4 small opacity-75 d-flex flex-column flex-md-row justify-content-between align-items-center"><p class="mb-2 mb-md-0">&copy; <?php echo date('Y'); ?> <?php echo $t['rights']; ?> - <?php echo htmlspecialchars($siteName); ?>.</p><div class="fs-5 d-flex gap-3 text-white opacity-50"><i class="fa-brands fa-cc-visa"></i><i class="fa-brands fa-cc-mastercard"></i><i class="fa-brands fa-cc-paypal"></i></div></div></div></footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script>
      var swiper1 = new Swiper(".gallerySwiper", {
        slidesPerView: 1, spaceBetween: 15, loop: true,
        autoplay: { delay: 2500, disableOnInteraction: false },
        navigation: { nextEl: ".gallerySwiper .swiper-button-next", prevEl: ".gallerySwiper .swiper-button-prev" },
        breakpoints: {
          640: { slidesPerView: 2, spaceBetween: 20 },
          768: { slidesPerView: 3, spaceBetween: 30 },
          1024: { slidesPerView: 4, spaceBetween: 30 },
        },
      });
      var swiper2 = new Swiper(".reviewsSwiper", {
        slidesPerView: 1, spaceBetween: 20, loop: true,
        autoplay: { delay: 3500, disableOnInteraction: false },
        pagination: { el: ".reviewsSwiper .swiper-pagination", clickable: true },
        breakpoints: { 640: { slidesPerView: 2, spaceBetween: 20 }, 1024: { slidesPerView: 3, spaceBetween: 30 } },
      });
    </script>
</body></html>