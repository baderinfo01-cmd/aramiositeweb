<?php
require_once 'includes/init.php';

$lang = $_SESSION['lang']; // ar أو en
$error = '';

// ==========================================
// قاموس ترجمة صفحة الدخول
// ==========================================
$t = [
    'page_title' => ($lang == 'ar') ? 'تسجيل الدخول' : 'Login',
    'welcome' => ($lang == 'ar') ? 'مرحباً بعودتك!' : 'Welcome Back!',
    'subtitle' => ($lang == 'ar') ? 'سجل الدخول للوصول إلى دوراتك' : 'Login to access your courses',
    'email' => ($lang == 'ar') ? 'البريد الإلكتروني' : 'Email Address',
    'password' => ($lang == 'ar') ? 'كلمة المرور' : 'Password',
    'btn_login' => ($lang == 'ar') ? 'دخول' : 'Login',
    'forgot_pass' => ($lang == 'ar') ? 'هل نسيت كلمة المرور؟' : 'Forgot Password?',
    'no_account' => ($lang == 'ar') ? 'ليس لديك حساب؟' : 'Don\'t have an account?',
    'register_now' => ($lang == 'ar') ? 'سجل الآن مجاناً' : 'Register for free',
    'hero_title' => 'Aramio Smart Global',
    'hero_desc' => ($lang == 'ar') ? 'منصتك الأولى للتعلم والتطور. استثمر في مهاراتك وانضم لنخبة من المتعلمين حول العالم.' : 'Your premier platform for learning and development. Invest in your skills and join elite learners worldwide.',
    
    // رسائل الخطأ
    'err_suspended' => ($lang == 'ar') ? 'هذا الحساب موقوف من قبل الإدارة.' : 'This account has been suspended by admin.',
    'err_invalid' => ($lang == 'ar') ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'Invalid email or password.'
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] == 0) {
            $error = $t['err_suspended'];
        } elseif ($user['is_verified'] == 0 && $user['role'] == 'trainee') {
            $_SESSION['temp_email'] = $email;
            header("Location: verify.php");
            exit();
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_name'] = $user['full_name'];

            if ($user['role'] == 'admin' || $user['role'] == 'staff') { header("Location: admin/index.php"); } 
            elseif ($user['role'] == 'trainer') { header("Location: trainer/index.php"); } 
            else { header("Location: trainee/index.php"); }
            exit();
        }
    } else {
        $error = $t['err_invalid'];
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t['page_title']; ?> | <?php echo htmlspecialchars($siteName); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <?php if($lang == 'ar'): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background-color: var(--secondary-color); display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px 0;}
        .auth-card { background: white; border-radius: 20px; box-shadow: 0 15px 35px rgba(11,28,63,0.1); overflow: hidden; width: 100%; max-width: 900px; display: flex; margin: 15px; }
        .auth-image { background: linear-gradient(135deg, rgba(11,28,63,0.9), rgba(28,200,138,0.8)), url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80') center/cover; width: 50%; color: white; padding: 50px; display: flex; flex-direction: column; justify-content: center; text-align: center; }
        .auth-form { width: 50%; padding: 50px; }
        .auth-form .form-control { border-radius: 30px; padding: 12px 20px; background-color: #f8f9fa; border: 1px solid #e9ecef; }
        .auth-form .form-control:focus { border-color: var(--accent-color); box-shadow: 0 0 0 0.2rem rgba(28,200,138,0.25); }
        .btn-auth { background-color: var(--primary-color); color: white; border-radius: 30px; padding: 12px; font-weight: bold; font-size: 1.1rem; transition: 0.3s; }
        .btn-auth:hover { background-color: var(--accent-color); color: white; transform: translateY(-2px); }
        
        @media (max-width: 768px) { 
            .auth-card { flex-direction: column; max-width: 450px; } 
            .auth-image { display: none !important; } 
            .auth-form { width: 100%; padding: 40px 25px; } 
            .auth-form h3 { font-size: 1.5rem; }
        }
    </style>
</head>
<body>

    <div class="auth-card">
        <div class="auth-form">
            
            <!-- زر العودة للرئيسية واللغة -->
            <div class="d-flex justify-content-between mb-4">
                <a href="index.php" class="text-muted text-decoration-none"><i class="fa-solid fa-house"></i></a>
                <a href="?lang=<?php echo ($lang == 'ar') ? 'en' : 'ar'; ?>" class="text-primary fw-bold text-decoration-none small"><i class="fa-solid fa-globe"></i> <?php echo ($lang == 'ar') ? 'English' : 'عربي'; ?></a>
            </div>

            <div class="text-center mb-4">
                <i class="fa-solid fa-graduation-cap fa-3x mb-3" style="color: var(--primary-color);"></i>
                <h3 class="fw-bold" style="color: var(--primary-color);"><?php echo $t['welcome']; ?></h3>
                <p class="text-muted"><?php echo $t['subtitle']; ?></p>
            </div>

            <?php if($error): ?><div class="alert alert-danger rounded-pill text-center small fw-bold"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error; ?></div><?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label <?php echo ($lang == 'ar') ? 'ms-3' : 'me-3'; ?> text-muted small fw-bold"><?php echo $t['email']; ?></label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 <?php echo ($lang == 'ar') ? 'rounded-start-pill' : 'rounded-start-pill border-end-0'; ?>"><i class="fa-solid fa-envelope text-muted"></i></span>
                        <input type="email" name="email" class="form-control border-0 bg-light <?php echo ($lang == 'ar') ? 'rounded-end-pill' : 'rounded-end-pill'; ?> text-start" required dir="ltr">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label <?php echo ($lang == 'ar') ? 'ms-3' : 'me-3'; ?> text-muted small fw-bold"><?php echo $t['password']; ?></label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 <?php echo ($lang == 'ar') ? 'rounded-start-pill' : 'rounded-start-pill border-end-0'; ?>"><i class="fa-solid fa-lock text-muted"></i></span>
                        <input type="password" name="password" class="form-control border-0 bg-light <?php echo ($lang == 'ar') ? 'rounded-end-pill' : 'rounded-end-pill'; ?> text-start" required dir="ltr">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-auth w-100 shadow-sm"><?php echo $t['btn_login']; ?> <i class="fa-solid <?php echo ($lang == 'ar') ? 'fa-arrow-left ms-2' : 'fa-arrow-right me-2'; ?>"></i></button>
            </form>
            
            <div class="text-center mt-4">
                <a href="#" class="text-decoration-none text-muted small d-block mb-2"><?php echo $t['forgot_pass']; ?></a>
                <span class="text-muted"><?php echo $t['no_account']; ?></span> <a href="register.php" class="text-decoration-none fw-bold" style="color: var(--accent-color);"><?php echo $t['register_now']; ?></a>
            </div>
        </div>

        <div class="auth-image">
            <h2 class="fw-bold mb-3"><?php echo $t['hero_title']; ?></h2>
            <p class="lead opacity-75"><?php echo $t['hero_desc']; ?></p>
        </div>
    </div>

</body>
</html>