<?php
require_once 'includes/init.php';

$lang = $_SESSION['lang'];
$error = '';
$verification_code_sent = '';

$t = [
    'page_title' => ($lang == 'ar') ? 'حساب جديد' : 'Sign Up',
    'header' => ($lang == 'ar') ? 'إنشاء حساب متدرب' : 'Create Trainee Account',
    'subtitle' => ($lang == 'ar') ? 'املأ البيانات بدقة لإكمال تسجيلك في الأكاديمية' : 'Fill in the details accurately to complete your registration.',
    'first_name' => ($lang == 'ar') ? 'الاسم الأول' : 'First Name',
    'last_name' => ($lang == 'ar') ? 'اللقب (العائلة)' : 'Last Name',
    'phone' => ($lang == 'ar') ? 'رقم الهاتف (للاتصال)' : 'Phone Number',
    'whatsapp' => ($lang == 'ar') ? 'رقم الواتساب (للتنبيهات)' : 'WhatsApp Number',
    'country' => ($lang == 'ar') ? 'بلد الإقامة' : 'Country',
    'select_country' => ($lang == 'ar') ? 'اختر بلدك...' : 'Select your country...',
    'email' => ($lang == 'ar') ? 'البريد الإلكتروني' : 'Email Address',
    'password' => ($lang == 'ar') ? 'كلمة المرور' : 'Password',
    'confirm_pass' => ($lang == 'ar') ? 'تأكيد كلمة المرور' : 'Confirm Password',
    'btn_register' => ($lang == 'ar') ? 'إنشاء حساب جديد' : 'Create Account',
    'have_account' => ($lang == 'ar') ? 'لديك حساب بالفعل؟' : 'Already have an account?',
    'login_now' => ($lang == 'ar') ? 'تسجيل الدخول' : 'Login',
    'hero_title' => ($lang == 'ar') ? 'انطلق نحو التميز' : 'Launch Towards Excellence',
    'hero_desc' => ($lang == 'ar') ? 'احصل على شهادات معتمدة، وتدرب على يد خبراء دوليين.' : 'Get certified and train with international experts.',
    'c_sa' => ($lang == 'ar') ? 'السعودية' : 'Saudi Arabia', 'c_dz' => ($lang == 'ar') ? 'الجزائر' : 'Algeria', 'c_eg' => ($lang == 'ar') ? 'مصر' : 'Egypt', 'c_ae' => ($lang == 'ar') ? 'الإمارات' : 'UAE', 'c_ma' => ($lang == 'ar') ? 'المغرب' : 'Morocco', 'c_other' => ($lang == 'ar') ? 'أخرى' : 'Other',
    'err_match' => ($lang == 'ar') ? 'كلمات المرور غير متطابقة!' : 'Passwords do not match!',
    'err_exists' => ($lang == 'ar') ? 'هذا البريد الإلكتروني مسجل بالفعل!' : 'This email is already registered!'
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);
    $whatsapp_number = trim($_POST['whatsapp_number']); // 💡 الحقل الجديد
    $country = trim($_POST['country']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = $t['err_match'];
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            $error = $t['err_exists'];
        } else {
            $v_code = rand(100000, 999999);
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // 💡 إدخال رقم الواتساب للقاعدة
            $insert = $pdo->prepare("INSERT INTO users (full_name, last_name, phone, whatsapp_number, country, email, password, role, verification_code, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 'trainee', ?, 0)");
            
            if ($insert->execute([$first_name, $last_name, $phone, $whatsapp_number, $country, $email, $hashed_password, $v_code])) {
                $_SESSION['temp_email'] = $email;
                $_SESSION['show_code_local'] = $v_code; 
                header("Location: verify.php");
                exit();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $t['page_title']; ?> | <?php echo htmlspecialchars($siteName); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <?php if($lang == 'ar'): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background-color: var(--secondary-color); display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px 0; }
        .auth-card { background: white; border-radius: 20px; box-shadow: 0 15px 35px rgba(11,28,63,0.1); overflow: hidden; width: 100%; max-width: 1000px; display: flex; margin: 15px; }
        .auth-image { background: linear-gradient(135deg, rgba(28,200,138,0.9), rgba(11,28,63,0.8)), url('https://images.unsplash.com/photo-1513258496099-48168024aec0?ixlib=rb-4.0.3') center/cover; width: 40%; color: white; padding: 50px; display: flex; flex-direction: column; justify-content: center; text-align: center; }
        .auth-form { width: 60%; padding: 40px 50px; }
        .auth-form .form-control, .auth-form .form-select { border-radius: 10px; padding: 12px 15px; background-color: #f8f9fa; border: 1px solid #e9ecef; font-size: 1rem; }
        .auth-form .form-control:focus, .auth-form .form-select:focus { border-color: var(--accent-color); box-shadow: 0 0 0 0.2rem rgba(28,200,138,0.25); }
        .btn-auth { background-color: var(--primary-color); color: white; border-radius: 30px; padding: 12px; font-weight: bold; font-size: 1.1rem; transition: 0.3s; border:none; }
        .btn-auth:hover { background-color: var(--accent-color); color: white; transform: translateY(-2px); }
        @media (max-width: 992px) { 
            .auth-card { flex-direction: column-reverse; max-width: 500px; } 
            .auth-image { width: 100%; padding: 30px 20px; } 
            .auth-form { width: 100%; padding: 30px 20px; }
            .auth-image h2 { font-size: 1.8rem; }
            .auth-image i { font-size: 3rem; margin-bottom: 15px !important; }
        }
    </style>
</head>
<body>

    <div class="auth-card">
        <div class="auth-form">
            
            <div class="d-flex justify-content-between mb-4">
                <a href="index.php" class="text-muted text-decoration-none"><i class="fa-solid fa-house"></i></a>
                <a href="?lang=<?php echo ($lang == 'ar') ? 'en' : 'ar'; ?>" class="text-primary fw-bold text-decoration-none small"><i class="fa-solid fa-globe"></i> <?php echo ($lang == 'ar') ? 'English' : 'عربي'; ?></a>
            </div>

            <div class="mb-4">
                <h3 class="fw-bold" style="color: var(--primary-color);"><?php echo $t['header']; ?></h3>
                <p class="text-muted small"><?php echo $t['subtitle']; ?></p>
            </div>

            <?php if($error): ?><div class="alert alert-danger p-2 text-center fw-bold small rounded-pill"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error; ?></div><?php endif; ?>

            <form method="POST">
                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['first_name']; ?></label>
                        <input type="text" name="first_name" class="form-control" required>
                    </div>
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['last_name']; ?></label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['phone']; ?></label>
                        <input type="tel" name="phone" class="form-control text-start" dir="ltr" placeholder="+..." required>
                    </div>
                    <!-- 💡 حقل الواتساب الجديد -->
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-success small fw-bold"><i class="fa-brands fa-whatsapp"></i> <?php echo $t['whatsapp']; ?> <span class="text-danger">*</span></label>
                        <input type="tel" name="whatsapp_number" class="form-control text-start border-success" dir="ltr" placeholder="+..." required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['email']; ?></label>
                        <input type="email" name="email" class="form-control text-start" dir="ltr" required>
                    </div>
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['country']; ?></label>
                        <select name="country" class="form-select" required>
                            <option value=""><?php echo $t['select_country']; ?></option>
                            <option value="السعودية"><?php echo $t['c_sa']; ?></option>
                            <option value="الجزائر"><?php echo $t['c_dz']; ?></option>
                            <option value="مصر"><?php echo $t['c_eg']; ?></option>
                            <option value="الإمارات"><?php echo $t['c_ae']; ?></option>
                            <option value="المغرب"><?php echo $t['c_ma']; ?></option>
                            <option value="أخرى"><?php echo $t['c_other']; ?></option>
                        </select>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['password']; ?></label>
                        <input type="password" name="password" class="form-control text-start" dir="ltr" required minlength="6">
                    </div>
                    <div class="col-12 col-md-6 mb-3">
                        <label class="form-label text-muted small fw-bold"><?php echo $t['confirm_pass']; ?></label>
                        <input type="password" name="confirm_password" class="form-control text-start" dir="ltr" required minlength="6">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-auth w-100 shadow-sm"><?php echo $t['btn_register']; ?> <i class="fa-solid fa-user-plus <?php echo ($lang == 'ar') ? 'ms-2' : 'me-2'; ?>"></i></button>
            </form>
            
            <div class="text-center mt-4 border-top pt-3">
                <span class="text-muted"><?php echo $t['have_account']; ?></span> <a href="login.php" class="text-decoration-none fw-bold" style="color: var(--primary-color);"><?php echo $t['login_now']; ?></a>
            </div>
        </div>

        <div class="auth-image">
            <i class="fa-solid fa-rocket fa-4x mb-4 opacity-75"></i>
            <h2 class="fw-bold mb-3"><?php echo $t['hero_title']; ?></h2>
            <p class="opacity-75"><?php echo $t['hero_desc']; ?></p>
        </div>
    </div>

</body>
</html>