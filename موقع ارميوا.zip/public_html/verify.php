<?php
require_once 'includes/init.php';

// منع الدخول إذا لم يأتِ من صفحة التسجيل
if (!isset($_SESSION['temp_email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['temp_email'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code_entered = trim($_POST['code']);

    // التعديل هنا: جلبنا full_name أيضاً لحفظه في الجلسة لاحقاً
    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE email = ? AND verification_code = ? LIMIT 1");
    $stmt->execute([$email, $code_entered]);
    $user = $stmt->fetch();

    if ($user) {
        // التوثيق صحيح: اجعل الحساب مفعل، وامسح الكود لكي لا يستخدم مرتين
        $pdo->prepare("UPDATE users SET is_verified = 1, verification_code = NULL WHERE id = ?")->execute([$user['id']]);
        
        // إدخاله للنظام مباشرة كمتدرب
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = 'trainee';
        $_SESSION['user_name'] = $user['full_name']; // <-- هذا السطر يحل المشكلة، يحفظ اسمه للوحة المتدرب
        
        unset($_SESSION['temp_email']);
        unset($_SESSION['show_code_local']);
        
        header("Location: trainee/index.php");
        exit();
    } else {
        $error = 'كود التحقق غير صحيح!';
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تأكيد الحساب | <?php echo $siteName; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Cairo', sans-serif; background-color: #f4f7f6; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .verify-card { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 450px; text-align: center; border-top: 5px solid #1cc88a; }
        .verify-card input { font-size: 2rem; text-align: center; letter-spacing: 5px; font-weight: bold; color: #0b1c3f; }
    </style>
</head>
<body>

    <div class="verify-card">
        <i class="fa-solid fa-envelope-circle-check fa-4x text-success mb-3"></i>
        <h3 class="fw-bold" style="color: #0b1c3f;">تأكيد البريد الإلكتروني</h3>
        <p class="text-muted mb-4">أرسلنا كود تحقق مكون من 6 أرقام إلى بريدك <br> <strong><?php echo $email; ?></strong></p>

        <?php if($error): ?><div class="alert alert-danger py-2"><?php echo $error; ?></div><?php endif; ?>

        <!-- رسالة المبرمج المؤقتة للسيرفر المحلي -->
        <?php if(isset($_SESSION['show_code_local'])): ?>
        <div class="alert alert-info py-2 small border-info">
            <i class="fa-solid fa-code"></i> <strong>للمبرمج (سيرفر محلي):</strong> الكود هو: <code><?php echo $_SESSION['show_code_local']; ?></code>
        </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-4">
                <input type="text" name="code" class="form-control" maxlength="6" placeholder="000000" dir="ltr" required autocomplete="off">
            </div>
            <button type="submit" class="btn btn-success w-100 rounded-pill fw-bold py-2 shadow-sm">تأكيد الحساب والدخول</button>
        </form>
    </div>

</body>
</html>