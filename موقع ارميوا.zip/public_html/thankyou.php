<?php
require_once 'includes/init.php';
$lang = isset($_GET['lang']) ? $_GET['lang'] : $_SESSION['lang'];

$contact_phone = getSetting($pdo, 'phone_number', $lang) ?: '+000000000';
$wa_link = "https://wa.me/" . str_replace('+', '', $contact_phone);

$t = [
    'title' => ($lang == 'ar') ? 'شكراً لك!' : 'Thank You!',
    'head' => ($lang == 'ar') ? 'تم استلام طلبك بنجاح' : 'Request Received Successfully',
    'msg' => ($lang == 'ar') ? 'نحن سعداء جداً بانضمامك لقائمة النخبة. سيقوم فريق الإدارة بمراجعة ملفك والاتصال بك قريباً (هاتفياً أو عبر الواتساب) لإرشادك حول كيفية تأكيد الحجز وإتمام الدفعة الأولى.' : 'We are thrilled to have you join the elite list. Our team will review your application and contact you soon (via Phone or WhatsApp) to guide you on confirming your booking and completing the first payment.',
    'wa_btn' => ($lang == 'ar') ? 'تواصل معنا عبر الواتساب للاستفسار' : 'Contact us on WhatsApp for inquiries',
    'back' => ($lang == 'ar') ? 'العودة للصفحة الرئيسية' : 'Back to Home'
];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t['title']; ?> | Aramio Smart Global</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Cairo', sans-serif; background-color: #f4f7f6; display: flex; align-items: center; justify-content: center; min-height: 100vh; text-align: center; }
        .thank-card { background: white; padding: 50px 30px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.05); max-width: 600px; border-top: 8px solid #1cc88a; }
        .icon-check { font-size: 6rem; color: #1cc88a; margin-bottom: 20px; animation: scaleUp 0.5s ease-out; }
        @keyframes scaleUp { 0% { transform: scale(0); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
    </style>
</head>
<body>
    <div class="container">
        <div class="thank-card mx-auto">
            <i class="fa-solid fa-circle-check icon-check"></i>
            <h1 class="fw-black mb-3" style="color: #0b1c3f;"><?php echo $t['head']; ?> <i class="fa-solid fa-party-horn text-warning"></i></h1>
            <p class="text-muted fs-5 lh-lg mb-4 fw-bold"><?php echo $t['msg']; ?></p>
            
            <div class="d-flex flex-column gap-3 align-items-center">
                <a href="<?php echo $wa_link; ?>" target="_blank" class="btn btn-success btn-lg rounded-pill fw-bold shadow-sm px-5" style="background-color: #25d366; border:none;">
                    <i class="fa-brands fa-whatsapp fs-4 me-2"></i> <?php echo $t['wa_btn']; ?>
                </a>
                <a href="index.php" class="text-decoration-none text-muted fw-bold mt-3 border-bottom border-secondary pb-1"><i class="fa-solid fa-arrow-left me-1"></i> <?php echo $t['back']; ?></a>
            </div>
        </div>
    </div>
</body>
</html>