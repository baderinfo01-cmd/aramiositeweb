<?php
require_once 'includes/init.php';
$lang = $_SESSION['lang']; 
$success_msg = ''; $error_msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_msg'])) {
    $insert = $pdo->prepare("INSERT INTO contact_messages (full_name, email, phone, message) VALUES (?, ?, ?, ?)");
    if ($insert->execute([trim($_POST['name']), trim($_POST['email']), trim($_POST['phone']), trim($_POST['message'])])) {
        $success_msg = ($lang == 'ar') ? "تم إرسال رسالتك بنجاح! فريقنا سيقوم بالرد عليك في أقرب وقت عبر البريد الإلكتروني أو الهاتف." : "Your message has been sent successfully! Our team will reply shortly.";
    } else {
        $error_msg = ($lang == 'ar') ? "حدث خطأ أثناء الإرسال، يرجى المحاولة لاحقاً." : "Error sending message, please try again later.";
    }
}

// 1. جلب إعدادات التواصل
$contact_email = getSetting($pdo, 'contact_email', $lang) ?: 'info@aramio.com'; 
$contact_phone = getSetting($pdo, 'phone_number', $lang) ?: '+000000000';
$fb_link = getSetting($pdo, 'facebook_link') ?: '#'; 
$tw_link = getSetting($pdo, 'twitter_link') ?: '#'; 
$ig_link = getSetting($pdo, 'instagram_link') ?: '#';
$yt_link = getSetting($pdo, 'youtube_link') ?: '#'; 

// 2. قاموس الترجمة
$t = [ 
    'home' => ($lang == 'ar') ? 'الرئيسية' : 'Home', 
    'about' => ($lang == 'ar') ? 'من نحن' : 'About Us', 
    'courses' => ($lang == 'ar') ? 'الدورات' : 'Courses', 
    'trainers' => ($lang == 'ar') ? 'المدربين' : 'Trainers', 
    'verify' => ($lang == 'ar') ? 'الشهادات' : 'Verify', 
    'contact' => ($lang == 'ar') ? 'تواصل معنا' : 'Contact Us', 
    'login' => ($lang == 'ar') ? 'تسجيل الدخول' : 'Login', 
    'register' => ($lang == 'ar') ? 'حساب جديد' : 'Sign Up', 
    'dashboard' => ($lang == 'ar') ? 'لوحة التحكم' : 'Dashboard',
    
    // نصوص صفحة التواصل
    'page_title' => ($lang == 'ar') ? 'تواصل معنا | أراميو' : 'Contact Us | Aramio',
    'hero_title' => ($lang == 'ar') ? 'نحن هنا للاستماع إليك' : 'We are here to listen',
    'hero_desc' => ($lang == 'ar') ? 'لديك استفسار حول دوراتنا؟ أو ترغب في التعاون معنا؟ لا تتردد في مراسلتنا وسنقوم بالرد عليك في أقرب فرصة.' : 'Have a question about our courses? Or want to collaborate? Feel free to reach out and we will reply as soon as possible.',
    
    'contact_info' => ($lang == 'ar') ? 'معلومات التواصل المباشر' : 'Direct Contact Info',
    'email_us' => ($lang == 'ar') ? 'راسلنا عبر البريد' : 'Email Us',
    'call_us' => ($lang == 'ar') ? 'اتصل بنا هاتفياً' : 'Call Us',
    'follow_us' => ($lang == 'ar') ? 'تابعنا على الشبكات' : 'Follow Us on Social Media',
    
    'form_title' => ($lang == 'ar') ? 'أرسل رسالتك الآن' : 'Send Your Message Now',
    'name' => ($lang == 'ar') ? 'الاسم الكامل' : 'Full Name', 
    'phone' => ($lang == 'ar') ? 'رقم الهاتف (اختياري)' : 'Phone (Optional)', 
    'msg' => ($lang == 'ar') ? 'نص الرسالة / الاستفسار' : 'Your Message / Inquiry', 
    'send' => ($lang == 'ar') ? 'إرسال الرسالة' : 'Send Message',
    
    'quick_links' => ($lang == 'ar') ? 'روابط سريعة' : 'Quick Links', 
    'rights' => ($lang == 'ar') ? 'جميع الحقوق محفوظة' : 'All Rights Reserved'
];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $t['page_title']; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <?php if($lang == 'ar'): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root { --primary: #0b1c3f; --accent: #1cc88a; --bg-light: #f4f7f6; } 
        html, body { max-width: 100vw; overflow-x: hidden; font-family: 'Cairo', sans-serif; background: #f8f9fc; } 
        
        /* Navbar */
        .navbar-custom { background: var(--primary); padding: 10px 0; box-shadow: 0 4px 10px rgba(0,0,0,0.1); } 
        .nav-link { color: #fff !important; font-weight: 600; } 
        .btn-outline { border: 1px solid #fff; color: #fff; border-radius: 30px; padding: 5px 20px; text-decoration: none; font-size: 0.9rem;} 
        .btn-solid { background: var(--accent); color: #fff; border-radius: 30px; padding: 6px 20px; text-decoration: none; font-weight: bold; border: none; } 
        
        /* Hero Section */
        .contact-hero { background: linear-gradient(135deg, var(--primary) 0%, #1a3673 100%); padding: 150px 0 80px; color: white; text-align: center; border-bottom: 5px solid var(--accent); }
        
        /* Contact Form Box */
        .contact-box { background: white; border-radius: 20px; padding: 40px; box-shadow: 0 15px 40px rgba(0,0,0,0.05); margin-top: -50px; position: relative; z-index: 10; border: 1px solid #eee; }
        .form-control { border-radius: 12px; padding: 15px 20px; background: #f8f9fa; border: 1px solid #e9ecef; font-weight: bold; }
        .form-control:focus { border-color: var(--accent); box-shadow: 0 0 0 0.2rem rgba(28,200,138,0.25); background: white; }
        .btn-submit { background: linear-gradient(90deg, var(--accent) 0%, #159f6d 100%); color: white; border-radius: 30px; padding: 15px; font-weight: 900; font-size: 1.2rem; border: none; width: 100%; transition: 0.3s; box-shadow: 0 10px 20px rgba(28,200,138,0.2); }
        .btn-submit:hover { transform: translateY(-3px); box-shadow: 0 15px 30px rgba(28,200,138,0.3); color: white; }
        
        /* Info Cards */
        .info-card { background: #fff; border-radius: 15px; padding: 25px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.03); border: 1px solid #eee; transition: 0.3s; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center; }
        .info-card:hover { transform: translateY(-5px); border-color: var(--accent); box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        .info-icon { width: 70px; height: 70px; background: rgba(28,200,138,0.1); color: var(--accent); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin-bottom: 20px; }
        
        .social-link { width: 50px; height: 50px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem; transition: 0.3s; margin: 0 5px; text-decoration: none; }
        .social-link:hover { transform: scale(1.1); color: white; }
        .bg-fb { background: #1877f2; } .bg-tw { background: #000000; } .bg-ig { background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); } .bg-yt { background: #ff0000; }

        @media (max-width: 768px) {
            .contact-hero { padding: 120px 15px 60px; }
            .contact-hero h1 { font-size: 2.2rem; }
            .contact-box { padding: 25px 15px; margin-top: -30px; border-radius: 15px; }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="assets/logo-desktop.png" class="d-none d-md-block" style="height: 45px;" alt="Logo" onerror="this.style.display='none'">
                <img src="assets/logo-mobile.png" class="d-block d-md-none" style="height: 35px;" alt="Logo" onerror="this.style.display='none'">
                <i class="fa-solid fa-graduation-cap fs-3 me-2 text-white d-block d-md-none" style="<?php echo file_exists('assets/logo-mobile.png') ? 'display:none!important;' : ''; ?>"></i>
                <span class="fw-bold fs-5 text-white" style="<?php echo file_exists('assets/logo-mobile.png') ? 'display:none!important;' : ''; ?>">Aramio</span>
            </a>
            <button class="navbar-toggler border-0 p-1" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon" style="width: 1.5em; height: 1.5em;"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 <?php echo ($lang == 'en') ? 'ms-auto me-0' : ''; ?>">
                    <li class="nav-item"><a class="nav-link" href="index.php"><?php echo $t['home']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php"><?php echo $t['about']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="courses.php"><?php echo $t['courses']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php#trainers"><?php echo $t['trainers']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php#verify"><?php echo $t['verify']; ?></a></li>
                    <li class="nav-item"><a class="nav-link active text-warning" href="contact.php"><?php echo $t['contact']; ?></a></li>
                </ul>
                <div class="d-flex align-items-center gap-2 mt-2 mt-lg-0 pb-3 pb-lg-0">
                    <a href="?lang=<?php echo ($lang == 'ar') ? 'en' : 'ar'; ?>" class="text-white fw-bold me-2 text-decoration-none">
                        <i class="fa-solid fa-globe"></i> <?php echo ($lang == 'ar') ? 'EN' : 'عربي'; ?>
                    </a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="login.php" class="btn-solid"><?php echo $t['dashboard']; ?></a>
                    <?php else: ?>
                        <a href="login.php" class="btn-outline"><?php echo $t['login']; ?></a>
                        <a href="register.php" class="btn-solid"><?php echo $t['register']; ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Header Hero -->
    <header class="contact-hero">
        <div class="container position-relative" style="z-index: 2;">
            <h1 class="display-4 fw-black mb-3"><?php echo $t['hero_title']; ?></h1>
            <p class="lead opacity-75 fw-bold w-75 mx-auto"><?php echo $t['hero_desc']; ?></p>
        </div>
    </header>

    <!-- Contact Content -->
    <section class="py-5 mb-5">
        <div class="container">
            <div class="row g-5">
                
                <!-- الفورم (على اليمين) -->
                <div class="col-lg-7">
                    <div class="contact-box">
                        <div class="text-center mb-4">
                            <h3 class="fw-black mb-2" style="color: var(--primary);"><i class="fa-solid fa-paper-plane text-accent me-2"></i> <?php echo $t['form_title']; ?></h3>
                            <div style="width: 50px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
                        </div>

                        <?php if($success_msg): ?> <div class="alert alert-success rounded-4 fw-bold text-center shadow-sm p-4"><i class="fa-solid fa-circle-check fa-2x mb-2 text-success"></i><br><?php echo $success_msg; ?></div> <?php endif; ?>
                        <?php if($error_msg): ?> <div class="alert alert-danger rounded-pill fw-bold text-center shadow-sm"><i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error_msg; ?></div> <?php endif; ?>

                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label text-muted small fw-bold"><?php echo $t['name']; ?> <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6 mb-3 mb-md-0">
                                    <label class="form-label text-muted small fw-bold">Email Address <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control text-start" dir="ltr" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label text-muted small fw-bold"><?php echo $t['phone']; ?></label>
                                    <input type="tel" name="phone" class="form-control text-start" dir="ltr" placeholder="+...">
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label text-muted small fw-bold"><?php echo $t['msg']; ?> <span class="text-danger">*</span></label>
                                <textarea name="message" class="form-control" rows="6" required></textarea>
                            </div>
                            <button type="submit" name="send_msg" class="btn btn-submit"><i class="fa-solid fa-envelope-open-text <?php echo ($lang == 'ar') ? 'ms-2' : 'me-2'; ?>"></i> <?php echo $t['send']; ?></button>
                        </form>
                    </div>
                </div>

                <!-- معلومات التواصل (على اليسار) -->
                <div class="col-lg-5 pt-lg-5">
                    <h4 class="fw-bold mb-4" style="color: var(--primary);"><i class="fa-solid fa-headset text-warning me-2"></i> <?php echo $t['contact_info']; ?></h4>
                    
                    <div class="row g-4">
                        <div class="col-12">
                            <div class="info-card">
                                <div class="info-icon"><i class="fa-solid fa-envelope"></i></div>
                                <h5 class="fw-bold text-dark mb-2"><?php echo $t['email_us']; ?></h5>
                                <a href="mailto:<?php echo htmlspecialchars($contact_email); ?>" class="fs-5 text-muted fw-bold text-decoration-none" dir="ltr"><?php echo htmlspecialchars($contact_email); ?></a>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="info-card">
                                <div class="info-icon"><i class="fa-solid fa-phone"></i></div>
                                <h5 class="fw-bold text-dark mb-2"><?php echo $t['call_us']; ?></h5>
                                <a href="tel:<?php echo str_replace('+', '', $contact_phone); ?>" class="fs-4 text-primary fw-bold text-decoration-none" dir="ltr"><?php echo htmlspecialchars($contact_phone); ?></a>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="info-card border-0 bg-transparent shadow-none p-0 mt-3">
                                <h5 class="fw-bold text-muted mb-4"><?php echo $t['follow_us']; ?></h5>
                                <div class="d-flex justify-content-center flex-wrap gap-2">
                                    <a href="<?php echo htmlspecialchars($fb_link); ?>" target="_blank" class="social-link bg-fb"><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href="<?php echo htmlspecialchars($tw_link); ?>" target="_blank" class="social-link bg-tw"><i class="fa-brands fa-x-twitter"></i></a>
                                    <a href="<?php echo htmlspecialchars($ig_link); ?>" target="_blank" class="social-link bg-ig"><i class="fa-brands fa-instagram"></i></a>
                                    <a href="<?php echo htmlspecialchars($yt_link); ?>" target="_blank" class="social-link bg-yt"><i class="fa-brands fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- الفوتر الموحد -->
    <footer class="pt-5 pb-3 text-center text-md-start <?php echo ($lang == 'en') ? 'text-start' : ''; ?>" style="background: var(--primary); color: white; border-top: 4px solid var(--accent);">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-md-5">
                    <h4 class="fw-bold mb-3"><i class="fa-solid fa-graduation-cap mx-2"></i> <?php echo htmlspecialchars($siteName); ?></h4>
                    <p class="small opacity-75 lh-lg pe-md-4">منصتك الأولى للتعلم عن بعد، نقدم دورات احترافية واستشارات معتمدة لبناء مستقبلك.</p>
                </div>
                <div class="col-md-3">
                    <h6 class="fw-bold mb-3 text-warning"><?php echo $t['quick_links']; ?></h6>
                    <ul class="list-unstyled small opacity-75 lh-lg">
                        <li><a href="index.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['home']; ?></a></li>
                        <li><a href="about.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['about']; ?></a></li>
                        <li><a href="courses.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['courses']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3 text-warning"><?php echo $t['contact_us']; ?></h6>
                    <p class="small opacity-75 mb-2" dir="ltr"><i class="fa-solid fa-envelope text-accent mx-2"></i> <?php echo htmlspecialchars($contact_email); ?></p>
                    <p class="small opacity-75 mb-0" dir="ltr"><i class="fa-solid fa-phone text-accent mx-2"></i> <span dir="ltr"><?php echo htmlspecialchars($contact_phone); ?></span></p>
                </div>
            </div>
            <div class="border-top border-light border-opacity-10 pt-3 mt-4 small opacity-75 d-flex flex-column flex-md-row justify-content-between align-items-center">
                <p class="mb-2 mb-md-0">&copy; <?php echo date('Y'); ?> <?php echo $t['rights']; ?> - <?php echo htmlspecialchars($siteName); ?>.</p>
                <div class="fs-5 d-flex gap-3 text-white opacity-50">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>