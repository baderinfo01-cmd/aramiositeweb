<?php
require_once 'includes/init.php';
$lang = $_SESSION['lang']; 

// 1. جلب جميع الأقسام النشطة للفلاتر
$categories = $pdo->query("SELECT id, name_{$lang} AS name FROM categories WHERE status = 1 ORDER BY id DESC")->fetchAll();

// 2. جلب جميع الدورات المنشورة مع التقييمات 
// (سيتم تصفيتها بالجافاسكربت لاحقاً لتسريع الصفحة)
$stmt = $pdo->query("
    SELECT c.*, u.full_name AS trainer_name, cat.name_{$lang} AS category_name,
           (SELECT COALESCE(AVG(rating), 0) FROM course_reviews WHERE course_id = c.id) AS avg_rating,
           (SELECT COUNT(*) FROM course_reviews WHERE course_id = c.id) AS reviews_count
    FROM courses c 
    JOIN users u ON c.trainer_id = u.id 
    JOIN categories cat ON c.category_id = cat.id 
    WHERE c.status = 'published' AND c.title_{$lang} IS NOT NULL AND c.title_{$lang} != ''
    ORDER BY c.created_at DESC
");
$all_courses = $stmt->fetchAll();

// إعدادات الفوتر والقاموس
$contact_email = getSetting($pdo, 'contact_email', $lang) ?: 'info@aramio.com'; 
$contact_phone = getSetting($pdo, 'phone_number', $lang) ?: '+000000000';
$fb_link = getSetting($pdo, 'facebook_link') ?: '#'; 
$tw_link = getSetting($pdo, 'twitter_link') ?: '#'; 
$ig_link = getSetting($pdo, 'instagram_link') ?: '#';
$yt_link = getSetting($pdo, 'youtube_link') ?: '#';

$t = [ 
    'home' => ($lang == 'ar') ? 'الرئيسية' : 'Home', 
    'about' => ($lang == 'ar') ? 'من نحن' : 'About Us', 
    'courses' => ($lang == 'ar') ? 'الدورات' : 'Courses', 
    'trainers' => ($lang == 'ar') ? 'المدربين' : 'Trainers', 
    'verify' => ($lang == 'ar') ? 'الشهادات' : 'Verify', 
    'contact' => ($lang == 'ar') ? 'تواصل معنا' : 'Contact Us', 
    'login' => ($lang == 'ar') ? 'تسجيل الدخول' : 'Login', 
    'register' => ($lang == 'ar') ? 'حساب جديد' : 'Sign Up', 
    'dashboard' => ($lang == 'ar') ? 'لوحة التحكم' : 'Dashboard', 
    'page_title' => ($lang == 'ar') ? 'جميع الدورات التدريبية' : 'All Training Courses',
    'page_desc' => ($lang == 'ar') ? 'اكتشف برامجنا المعتمدة وابدأ رحلة التميز معنا.' : 'Discover our certified programs and start your journey of excellence.',
    'search' => ($lang == 'ar') ? 'ابحث عن دورة...' : 'Search for a course...',
    'all_cats' => ($lang == 'ar') ? 'جميع التخصصات' : 'All Categories',
    'all_types' => ($lang == 'ar') ? 'كل أنواع التدريب' : 'All Training Types',
    'online' => ($lang == 'ar') ? 'أونلاين مسجلة' : 'Online (Recorded)',
    'online_live' => ($lang == 'ar') ? 'بث مباشر (Zoom)' : 'Live Stream (Zoom)',
    'offline' => ($lang == 'ar') ? 'حضوري' : 'Offline',
    'course_details' => ($lang == 'ar') ? 'التفاصيل والتسجيل' : 'Details & Enroll',
    'no_results' => ($lang == 'ar') ? 'لا توجد دورات تطابق بحثك حالياً.' : 'No courses match your search currently.',
    'quick_links' => ($lang == 'ar') ? 'روابط سريعة' : 'Quick Links', 
    'rights' => ($lang == 'ar') ? 'جميع الحقوق محفوظة' : 'All Rights Reserved'
];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $t['page_title']; ?> | <?php echo htmlspecialchars($siteName); ?></title>
    
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <?php if($lang == 'ar'): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        .page-header { background: linear-gradient(135deg, var(--primary) 0%, #1a3673 100%); padding: 120px 0 60px; color: white; text-align: center; border-bottom: 5px solid var(--accent); }
        .filter-box { background: white; border-radius: 20px; padding: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-top: -40px; position: relative; z-index: 10; border: 1px solid #eee; }
        .filter-control { border-radius: 30px; padding: 12px 20px; background: #f8f9fa; border: 1px solid #e9ecef; font-weight: bold; }
        .filter-control:focus { border-color: var(--accent); box-shadow: 0 0 0 0.2rem rgba(28,200,138,0.25); background: white; }
        .course-card { height: 100%; display: flex; flex-direction: column; transition: 0.3s; }
        .course-img-wrapper { position: relative; overflow: hidden; border-radius: 15px 15px 0 0; }
        .course-img-wrapper img { transition: 0.5s; }
        .course-card:hover .course-img-wrapper img { transform: scale(1.1); }
        
        /* تأثيرات إخفاء وإظهار الفلاتر */
        .course-item { transition: all 0.4s ease-in-out; }
        .hidden-course { display: none !important; }
    </style>
</head>
<body class="bg-light">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="assets/logo-desktop.png" class="d-none d-md-block" style="height: 45px;" alt="Logo" onerror="this.style.display='none'">
                <img src="assets/logo-mobile.png" class="d-block d-md-none" style="height: 35px;" alt="Logo" onerror="this.style.display='none'">
                <i class="fa-solid fa-graduation-cap fs-3 me-2 text-white d-block d-md-none" style="<?php echo file_exists('assets/logo-mobile.png') ? 'display:none!important;' : ''; ?>"></i>
                <span class="fw-bold fs-5 text-white" style="<?php echo file_exists('assets/logo-mobile.png') ? 'display:none!important;' : ''; ?>">Aramio</span>
            </a>
            <button class="navbar-toggler border-0 p-1" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon" style="width: 1.5em; height: 1.5em;"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 <?php echo ($lang == 'en') ? 'ms-auto me-0' : ''; ?>">
                    <li class="nav-item"><a class="nav-link" href="index.php"><?php echo $t['home']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php"><?php echo $t['about']; ?></a></li>
                    <li class="nav-item"><a class="nav-link active" href="courses.php"><?php echo $t['courses']; ?></a></li>
                    <li class="nav-item"><a class="nav-link text-warning" href="contact.php"><?php echo $t['contact']; ?></a></li>
                </ul>
                <div class="d-flex align-items-center gap-2 mt-2 mt-lg-0 pb-3 pb-lg-0">
                    <a href="?lang=<?php echo ($lang == 'ar') ? 'en' : 'ar'; ?>" class="text-white fw-bold me-2 text-decoration-none">
                        <i class="fa-solid fa-globe"></i> <?php echo ($lang == 'ar') ? 'EN' : 'عربي'; ?>
                    </a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="login.php" class="btn-solid"><?php echo $t['dashboard']; ?></a>
                    <?php else: ?>
                        <a href="login.php" class="btn-outline"><?php echo $t['login']; ?></a>
                        <a href="register.php" class="btn-solid"><?php echo $t['register']; ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <header class="page-header">
        <div class="container">
            <h1 class="display-4 fw-black mb-3"><?php echo $t['page_title']; ?></h1>
            <p class="lead opacity-75 fw-bold"><?php echo $t['page_desc']; ?></p>
        </div>
    </header>

    <!-- 💡 الفلاتر الذكية (Smart Filters) -->
    <div class="container">
        <div class="filter-box">
            <div class="row g-3">
                <div class="col-lg-4 col-md-12">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 rounded-start-pill text-muted px-3"><i class="fa-solid fa-magnifying-glass"></i></span>
                        <input type="text" id="searchInput" class="form-control filter-control border-0 rounded-end-pill" placeholder="<?php echo $t['search']; ?>" onkeyup="filterCourses()">
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <select id="categoryFilter" class="form-select filter-control" onchange="filterCourses()">
                        <option value="all"><?php echo $t['all_cats']; ?></option>
                        <?php foreach($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-4 col-md-6">
                    <select id="typeFilter" class="form-select filter-control" onchange="filterCourses()">
                        <option value="all"><?php echo $t['all_types']; ?></option>
                        <option value="online"><?php echo $t['online']; ?></option>
                        <option value="online_live"><?php echo $t['online_live']; ?></option>
                        <option value="offline"><?php echo $t['offline']; ?></option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- شبكة الدورات -->
    <section class="py-5">
        <div class="container">
            <div class="row g-4" id="coursesGrid">
                
                <?php if(empty($all_courses)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="fa-solid fa-folder-open fa-4x text-muted opacity-25 mb-3"></i>
                        <h4 class="fw-bold text-muted">لا توجد دورات منشورة حالياً.</h4>
                    </div>
                <?php else: ?>
                    <?php foreach($all_courses as $course): ?>
                    <div class="col-md-6 col-lg-4 course-item" 
                         data-title="<?php echo strtolower(htmlspecialchars($course['title_'.$lang] ?? $course['title_ar'])); ?>" 
                         data-category="<?php echo $course['category_id']; ?>" 
                         data-type="<?php echo $course['training_type']; ?>">
                         
                        <div class="card course-card">
                            <div class="course-img-wrapper position-relative">
                                <img src="<?php echo ($course['thumbnail'] && $course['thumbnail'] != 'default_course.jpg') ? 'uploads/courses/'.$course['thumbnail'] : 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3'; ?>" class="card-img-top course-img" alt="Course">
                                <div class="position-absolute top-0 end-0 m-3">
                                    <?php if($course['training_type'] == 'online'): ?><span class="badge bg-primary px-3 py-2 rounded-pill shadow"><i class="fa-solid fa-globe"></i> <?php echo $t['online']; ?></span>
                                    <?php elseif($course['training_type'] == 'online_live'): ?><span class="badge bg-danger px-3 py-2 rounded-pill shadow"><i class="fa-solid fa-satellite-dish"></i> <?php echo $t['online_live']; ?></span>
                                    <?php else: ?><span class="badge bg-info text-dark px-3 py-2 rounded-pill shadow"><i class="fa-solid fa-building"></i> <?php echo $t['offline']; ?></span><?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="card-body p-4 d-flex flex-column">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge bg-light text-primary border align-self-start"><?php echo htmlspecialchars($course['category_name'] ?? 'عام'); ?></span>
                                    <div class="text-warning small fw-bold">
                                        <span class="text-dark me-1"><?php echo round($course['avg_rating'], 1); ?></span>
                                        <i class="fa-solid fa-star"></i> <span class="text-muted fw-normal">(<?php echo $course['reviews_count']; ?>)</span>
                                    </div>
                                </div>
                                
                                <h5 class="card-title fw-bold mb-3 flex-grow-1" style="color: var(--primary);"><?php echo htmlspecialchars($course['title_'.$lang] ?? $course['title_ar']); ?></h5>
                                <div class="text-muted small fw-bold mb-3"><i class="fa-solid fa-user-tie text-primary mx-1"></i> <?php echo htmlspecialchars($course['trainer_name']); ?></div>
                                
                                <hr class="opacity-25 my-auto">
                                
                                <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-3">
                                    <span class="fw-bold fs-5 text-success">
                                        <?php 
                                            $prices = [];
                                            if($course['price_usd']) $prices[] = '$'.(float)$course['price_usd'];
                                            if($course['price_dzd']) $prices[] = (float)$course['price_dzd'].' د.ج';
                                            echo implode(' <br class="d-md-none"> ', $prices); 
                                        ?>
                                    </span>
                                    <a href="course.php?id=<?php echo $course['id']; ?>" class="btn btn-outline-primary rounded-pill px-4 fw-bold shadow-sm" style="border-width: 2px;"><?php echo $t['course_details']; ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <!-- رسالة لا توجد نتائج للبحث -->
                <div id="noResultsMsg" class="col-12 text-center py-5" style="display: none;">
                    <i class="fa-solid fa-magnifying-glass-minus fa-3x text-muted opacity-25 mb-3"></i>
                    <h5 class="fw-bold text-muted"><?php echo $t['no_results']; ?></h5>
                </div>
            </div>
        </div>
    </section>

    <!-- الفوتر الموحد -->
    <footer class="pt-5 pb-3 text-center text-md-start <?php echo ($lang == 'en') ? 'text-start' : ''; ?>" style="background: var(--primary); color: white; border-top: 4px solid var(--accent);">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-md-5">
                    <h4 class="fw-bold mb-3"><i class="fa-solid fa-graduation-cap mx-2"></i> <?php echo htmlspecialchars($siteName); ?></h4>
                    <p class="small opacity-75 lh-lg pe-md-4">منصتك الأولى للتعلم عن بعد، نقدم دورات احترافية واستشارات معتمدة لبناء مستقبلك.</p>
                    <div class="d-flex gap-3 mt-3 justify-content-center justify-content-md-start">
                        <a href="<?php echo htmlspecialchars($fb_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-facebook"></i></a>
                        <a href="<?php echo htmlspecialchars($yt_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-youtube text-danger"></i></a>
                        <a href="<?php echo htmlspecialchars($ig_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-3">
                    <h6 class="fw-bold mb-3 text-warning"><?php echo $t['quick_links']; ?></h6>
                    <ul class="list-unstyled small opacity-75 lh-lg">
                        <li><a href="index.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['home']; ?></a></li>
                        <li><a href="about.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['about']; ?></a></li>
                        <li><a href="contact.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['contact']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3 text-warning"><?php echo $t['contact_us']; ?></h6>
                    <p class="small opacity-75 mb-2" dir="ltr"><i class="fa-solid fa-envelope text-accent mx-2"></i> <?php echo htmlspecialchars($contact_email); ?></p>
                    <p class="small opacity-75 mb-0" dir="ltr"><i class="fa-solid fa-phone text-accent mx-2"></i> <span dir="ltr"><?php echo htmlspecialchars($contact_phone); ?></span></p>
                </div>
            </div>
            <div class="border-top border-light border-opacity-10 pt-3 mt-4 small opacity-75 d-flex flex-column flex-md-row justify-content-between align-items-center">
                <p class="mb-2 mb-md-0">&copy; <?php echo date('Y'); ?> <?php echo $t['rights']; ?> - <?php echo htmlspecialchars($siteName); ?>.</p>
                <div class="fs-5 d-flex gap-3 text-white opacity-50">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- 💡 سكريبت الفلاتر الذكية المباشرة (بدون تحميل الصفحة) -->
    <script>
        function filterCourses() {
            let searchVal = document.getElementById('searchInput').value.toLowerCase();
            let catVal = document.getElementById('categoryFilter').value;
            let typeVal = document.getElementById('typeFilter').value;
            
            let courses = document.querySelectorAll('.course-item');
            let visibleCount = 0;

            courses.forEach(function(course) {
                let title = course.getAttribute('data-title');
                let cat = course.getAttribute('data-category');
                let type = course.getAttribute('data-type');
                
                let matchSearch = title.includes(searchVal);
                let matchCat = (catVal === 'all' || catVal === cat);
                let matchType = (typeVal === 'all' || typeVal === type);
                
                if (matchSearch && matchCat && matchType) {
                    course.classList.remove('hidden-course');
                    visibleCount++;
                } else {
                    course.classList.add('hidden-course');
                }
            });

            // إظهار أو إخفاء رسالة "لا توجد نتائج"
            let noResMsg = document.getElementById('noResultsMsg');
            if (visibleCount === 0) {
                noResMsg.style.display = 'block';
            } else {
                noResMsg.style.display = 'none';
            }
        }
    </script>
</body>
</html>