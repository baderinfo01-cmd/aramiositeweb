<?php
require_once 'includes/init.php';
$lang = $_SESSION['lang']; 

// 1. جلب الدورات المنشورة 
$courses_stmt = $pdo->query("
    SELECT c.*, u.full_name AS trainer_name, cat.name_{$lang} AS category_name 
    FROM courses c 
    JOIN users u ON c.trainer_id = u.id 
    JOIN categories cat ON c.category_id = cat.id 
    WHERE c.status = 'published' 
    ORDER BY c.created_at DESC 
    LIMIT 4
");
$published_courses = $courses_stmt->fetchAll();

// 2. جلب الإحصائيات
$stat_courses = getSetting($pdo, 'stat_courses', $lang) ?: '0'; 
$stat_students = getSetting($pdo, 'stat_students', $lang) ?: '0'; 
$stat_trainers = getSetting($pdo, 'stat_trainers', $lang) ?: '0'; 
$stat_consultations = getSetting($pdo, 'stat_consultations', $lang) ?: '0';

// 3. جلب المدربين والآراء
$trainers = $pdo->query("SELECT id, full_name, avatar, bio, country FROM users WHERE role = 'trainer' AND status = 1 LIMIT 4")->fetchAll();
$testimonials = $pdo->query("SELECT * FROM testimonials WHERE status = 1 ORDER BY id DESC LIMIT 3")->fetchAll();
$db_gallery = $pdo->query("SELECT image_name FROM gallery_images WHERE image_type = 'gallery' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_COLUMN);
$db_reviews = $pdo->query("SELECT image_name FROM gallery_images WHERE image_type = 'review' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_COLUMN);

// 4. جلب الإشعارات
$popups = $pdo->query("SELECT message_{$lang} AS msg FROM popup_notifications WHERE status = 1 ORDER BY RAND() LIMIT 5")->fetchAll(PDO::FETCH_COLUMN);

// 5. جلب إعدادات الإعلان والتواصل حسب اللغة
if ($lang == 'en') { 
    $promo_title = getSetting($pdo, 'promo_title_en', 'en'); 
    $promo_subtitle = getSetting($pdo, 'promo_subtitle_en', 'en'); 
    $promo_link = getSetting($pdo, 'promo_link_en', 'en'); 
} else { 
    $promo_title = getSetting($pdo, 'promo_title', 'ar'); 
    $promo_subtitle = getSetting($pdo, 'promo_subtitle', 'ar'); 
    $promo_link = getSetting($pdo, 'promo_link', 'ar'); 
}

$promo_date = getSetting($pdo, 'promo_end_date', 'ar');
$contact_email = getSetting($pdo, 'contact_email', $lang) ?: 'info@aramio.com'; 
$contact_phone = getSetting($pdo, 'phone_number', $lang) ?: '+000000000';
$fb_link = getSetting($pdo, 'facebook_link') ?: '#'; 
$tw_link = getSetting($pdo, 'twitter_link') ?: '#'; 
$ig_link = getSetting($pdo, 'instagram_link') ?: '#';
$yt_link = getSetting($pdo, 'youtube_link') ?: '#'; 

// 6. القاموس الشامل 
$t = [ 
    'home' => ($lang == 'ar') ? 'الرئيسية' : 'Home', 
    'about' => ($lang == 'ar') ? 'من نحن' : 'About Us', 
    'courses' => ($lang == 'ar') ? 'الدورات' : 'Courses', 
    'trainers' => ($lang == 'ar') ? 'المدربين' : 'Trainers', 
    'verify' => ($lang == 'ar') ? 'الشهادات' : 'Verify', 
    'contact' => ($lang == 'ar') ? 'تواصل معنا' : 'Contact Us', 
    'login' => ($lang == 'ar') ? 'تسجيل الدخول' : 'Login', 
    'register' => ($lang == 'ar') ? 'حساب جديد' : 'Sign Up', 
    'dashboard' => ($lang == 'ar') ? 'لوحة التحكم' : 'Dashboard', 
    'hero_title' => ($lang == 'ar') ? 'استثمر في مستقبلك مع أراميو' : 'Invest in your future with Aramio', 
    'hero_desc' => ($lang == 'ar') ? 'أكاديمية أراميو توفر لك أفضل الدورات التدريبية والاستشارات.' : 'Aramio Academy provides the best training courses.', 
    'browse_courses' => ($lang == 'ar') ? 'تصفح الدورات الآن' : 'Browse Courses Now', 
    'latest_courses' => ($lang == 'ar') ? 'أحدث الدورات التدريبية' : 'Latest Courses', 
    'course_details' => ($lang == 'ar') ? 'التفاصيل' : 'Details', 
    'show_more' => ($lang == 'ar') ? 'عرض المزيد من الدورات' : 'View All Courses', 
    'stats_courses' => ($lang == 'ar') ? 'الدورات' : 'Courses', 
    'stats_students' => ($lang == 'ar') ? 'الطلاب' : 'Students', 
    'stats_trainers' => ($lang == 'ar') ? 'المدربين' : 'Trainers', 
    'stats_cons' => ($lang == 'ar') ? 'الاستشارات' : 'Consultations', 
    'trainers_title' => ($lang == 'ar') ? 'نخبة الخبراء والمدربين' : 'Our Elite Trainers', 
    'testimonials_title' => ($lang == 'ar') ? 'آراء وتقييمات لخدماتنا' : 'Reviews & Feedback', 
    'verify_title' => ($lang == 'ar') ? 'التحقق من الشهادة' : 'Certificate Verification', 
    'verify_desc' => ($lang == 'ar') ? 'أدخل رقم الشهادة للتأكد من صحتها.' : 'Enter certificate ID.', 
    'verify_placeholder' => ($lang == 'ar') ? 'رقم الشهادة (مثال: AR-12345)' : 'Certificate ID (e.g. AR-12345)', 
    'verify_btn' => ($lang == 'ar') ? 'تحقق الآن' : 'Verify Now', 
    'quick_links' => ($lang == 'ar') ? 'روابط سريعة' : 'Quick Links', 
    'rights' => ($lang == 'ar') ? 'جميع الحقوق محفوظة' : 'All Rights Reserved', 
    'global_presence' => ($lang == 'ar') ? 'تواجدنـا العـالمي' : 'Our Global Presence', 
    'gallery_title' => ($lang == 'ar') ? 'معرض الصور الميدانية' : 'Field Gallery',
    'days' => ($lang == 'ar') ? 'أيام' : 'Days', 'hours' => ($lang == 'ar') ? 'ساعات' : 'Hours', 'mins' => ($lang == 'ar') ? 'دقائق' : 'Mins', 'secs' => ($lang == 'ar') ? 'ثواني' : 'Secs', 'ended' => ($lang == 'ar') ? 'انتهى العرض' : 'Offer Ended', 'now' => ($lang == 'ar') ? 'الآن' : 'Now',
    'cert_valid' => ($lang == 'ar') ? 'تهانينا! شهادتك صالحة. يرجى الاطلاع أدناه على التفاصيل' : 'Congratulations! Valid Certificate. See details below:',
    'cert_fname' => ($lang == 'ar') ? 'الاسم الأول' : 'First Name', 'cert_lname' => ($lang == 'ar') ? 'اسم العائلة' : 'Last Name', 'cert_nat' => ($lang == 'ar') ? 'الجنسية' : 'Nationality', 'cert_spec' => ($lang == 'ar') ? 'التخصص' : 'Specialty', 'cert_grade' => ($lang == 'ar') ? 'الدرجة' : 'Grade', 'cert_result' => ($lang == 'ar') ? 'النتيجة' : 'Result', 'cert_passed' => ($lang == 'ar') ? 'ناجح' : 'Passed', 'cert_id' => ($lang == 'ar') ? 'رقم الشهادة' : 'Certificate ID', 'cert_date' => ($lang == 'ar') ? 'تاريخ الإصدار' : 'Issue Date', 'cert_help' => ($lang == 'ar') ? 'في حال وجود أي استفسار، تواصل معنا عبر' : 'For any inquiries, contact us via', 'cert_not_found' => ($lang == 'ar') ? 'عذراً، رقم الشهادة غير مسجل في قاعدة بياناتنا.' : 'Sorry, this certificate ID is not registered in our database.'
];
$flags = ['الجزائر'=>'🇩🇿', 'السعودية'=>'🇸🇦', 'مصر'=>'🇪🇬', 'الإمارات'=>'🇦🇪', 'المغرب'=>'🇲🇦', 'تونس'=>'🇹🇳', 'ماليزيا'=>'🇲🇾'];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($siteName); ?> | <?php echo $t['home']; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <?php if($lang == 'ar'): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    
    <style>
        :root { --primary: #0b1c3f; --accent: #1cc88a; --bg-light: #f4f7f6; } 
        html, body { max-width: 100vw; overflow-x: hidden; font-family: 'Cairo', sans-serif; background: #fff; } 
        .navbar-custom { background: var(--primary); padding: 10px 0; box-shadow: 0 4px 10px rgba(0,0,0,0.1); } 
        .nav-link { color: #fff !important; font-weight: 600; } 
        .btn-outline { border: 1px solid #fff; color: #fff; border-radius: 30px; padding: 5px 20px; text-decoration: none; font-size: 0.9rem;} 
        .btn-solid { background: var(--accent); color: #fff; border-radius: 30px; padding: 6px 20px; text-decoration: none; font-weight: bold; border: none; } 
        .hero-section { background: linear-gradient(rgba(11,28,63,0.85), rgba(11,28,63,0.95)), url('https://scontent-zrh1-1.xx.fbcdn.net/v/t39.30808-6/591762519_1363912605746126_2609040291748718871_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeFRUP6pCQesxazR_6TkW1gN4MGvO7_uBOHgwa87v-4E4Sh27PkY0OaRyyD3ubs0rIZEMBt72sqWCOraQrEtlLRX&_nc_ohc=gnLvYBjCDNcQ7kNvwH7l8YG&_nc_oc=AdqfSLbCoyO01eiJVSNI9u_o2qTibXaSbiCsd7cvrqC7IrcEnqpHZzL98ASCefpsxRk0seEnyI3OWAGpmDc9gbkA&_nc_zt=23&_nc_ht=scontent-zrh1-1.xx&_nc_gid=wP2DFryh3JYWqczlsy30ow&_nc_ss=7a3a8&oh=00_Af08K5sffVBLCWm716M8VIlCN9NWzxFsU9SSHkDmtCc7WA&oe=69E59618') center/cover; padding: 150px 0 80px; text-align: center; color: white; } 
        .promo-banner { background: linear-gradient(135deg, var(--primary) 0%, #1a3673 100%); padding: 50px 0; color: white; border-bottom: 4px solid var(--accent); } 
        .timer-wrap { display: flex; justify-content: center; gap: 15px; margin-top: 20px; direction: ltr; } 
        .time-box { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 12px; padding: 15px; min-width: 80px; text-align: center; } 
        .time-box span { display: block; font-size: 2.5rem; font-weight: 800; color: var(--accent); line-height: 1; } 
        .stats-section { background-color: var(--bg-light); padding: 60px 0; } 
        .stat-card { background: #fff; padding: 30px 10px; border-radius: 20px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.05); height: 100%; border-bottom: 4px solid var(--accent); } 
        .stat-icon { width: 60px; height: 60px; background: rgba(28,200,138,0.1); color: var(--accent); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; margin: 0 auto 15px; } 
        .stat-card h3 { font-size: 2rem; font-weight: 800; color: var(--primary); margin:0; } 
        .course-card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); overflow: hidden; height: 100%; display: flex; flex-direction: column; } 
        .course-img { height: 180px; object-fit: cover; width: 100%; } 
        
        /* 💡 تم تصحيح شكل كروت התقييمات لتكون متساوية وأنيقة */
        .test-card { background: #fff; padding: 40px 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border: 1px solid #f4f7f6; transition: 0.3s; position: relative; z-index: 1; display: flex; flex-direction: column; height: 100%; } 
        .test-card:hover { transform: translateY(-10px); box-shadow: 0 15px 40px rgba(11,28,63,0.1); border-color: var(--accent); } 
        .test-card::after { content: '\f10e'; font-family: 'Font Awesome 6 Free'; font-weight: 900; position: absolute; top: 25px; <?php echo ($lang == 'ar') ? 'left' : 'right'; ?>: 25px; font-size: 5rem; color: rgba(28, 200, 138, 0.05); z-index: -1; } 
        .test-text { flex-grow: 1; font-size: 1.05rem; line-height: 1.8; color: #555; margin-bottom: 25px; } 
        .test-client { display: flex; align-items: center; gap: 15px; border-top: 1px solid #f0f0f0; padding-top: 20px; text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>; } 
        .test-client-img { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; border: 2px solid var(--accent); padding: 2px; } 
        
        .verify-section { background-color: var(--primary); padding: 80px 0; color: white; border-top: 4px solid var(--accent); } 
        .verify-box { background: rgba(255,255,255,0.05); padding: 40px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.1); } 
        .trainer-elite-card { background: #fff; border-radius: 20px; padding: 30px 15px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.04); transition: 0.3s; cursor: pointer; border: 1px solid #f0f0f0; position: relative; overflow: hidden; } 
        .trainer-elite-card:hover { transform: translateY(-10px); box-shadow: 0 15px 40px rgba(11,28,63,0.1); border-color: var(--accent); } 
        .trainer-elite-card::before { content:''; position: absolute; top:0; left:0; width:100%; height: 5px; background: var(--accent); } 
        .trainer-elite-img { width: 110px; height: 110px; border-radius: 50%; object-fit: cover; border: 4px solid #fff; box-shadow: 0 8px 20px rgba(0,0,0,0.12); margin-bottom: 15px; } 
        .trainer-stars { color: #f6c23e; font-size: 0.85rem; margin-bottom: 10px; } 
        .trainer-flag { font-size: 1.2rem; } 
        .float-whatsapp { position: fixed; bottom: 30px; <?php echo ($lang=='ar')?'left':'right'; ?>: 30px; background-color: #25d366; color: white; border-radius: 50%; width: 60px; height: 60px; text-align: center; font-size: 35px; box-shadow: 0px 4px 10px rgba(0,0,0,0.15); z-index: 1000; transition: 0.3s; display: flex; align-items: center; justify-content: center; text-decoration: none; } 
        .float-whatsapp:hover { background-color: #128c7e; color: white; transform: scale(1.1); } 
        .toast-container { position: fixed; bottom: 20px; <?php echo ($lang=='ar')?'right':'left'; ?>: 20px; z-index: 1050; } 
        .custom-toast { background: #fff; border-right: 5px solid var(--accent); box-shadow: 0 10px 30px rgba(0,0,0,0.1); border-radius: 8px; padding: 15px 20px; display: flex; align-items: center; gap: 15px; transform: translateY(100px); opacity: 0; transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55); width: 320px; } 
        .custom-toast.show { transform: translateY(0); opacity: 1; }
        
        /* 💡 الشريط المتحرك الجديد לדول التواجد */
        .marquee-wrapper { background: #fff; padding: 20px 0; border-bottom: 1px solid #eee; overflow: hidden; position: relative; }
        .marquee-content { display: flex; align-items: center; width: fit-content; animation: marquee 15s linear infinite; }
        /* مضاعفة السرعة في الهواتف */
        @media (max-width: 768px) { .marquee-content { animation-duration: 10s; } }
        .marquee-item { display: flex; align-items: center; gap: 10px; padding: 10px 30px; background: rgba(11,28,63,0.03); border: 1px solid rgba(11,28,63,0.05); border-radius: 30px; margin: 0 15px; white-space: nowrap; }
        .marquee-item span { font-size: 1.1rem; font-weight: 800; color: var(--primary); }
        .marquee-item .flag { font-size: 1.5rem; }
        
        /* حركة الأنيميشن */
        @keyframes marquee { 
            0% { transform: translateX(0); } 
            100% { transform: translateX(calc(-50% - 15px)); } /* النصف لتجنب الانقطاع المفاجئ عند تكرار العناصر */
        }
        <?php if($lang == 'ar'): ?> 
        @keyframes marquee { 
            0% { transform: translateX(0); } 
            100% { transform: translateX(calc(50% + 15px)); } 
        } 
        <?php endif; ?>
        
        .swiper-button-next, .swiper-button-prev { color: var(--accent) !important; background: white; width: 40px; height: 40px; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .swiper-button-next:after, .swiper-button-prev:after { font-size: 1.2rem !important; font-weight: bold; }

        @media (max-width: 768px) { 
            .hero-section { padding: 120px 15px 40px; } .hero-section h1 { font-size: 2rem; } .hero-section p { font-size: 1rem; width: 100% !important; } 
            .promo-banner { padding: 30px 10px; } .timer-wrap { gap: 8px; } .time-box { min-width: 60px; padding: 10px 5px; border-radius: 8px; } .time-box span { font-size: 1.5rem; } .time-box small { font-size: 0.8rem; } 
            .course-img { height: 110px; } .course-card .card-body { padding: 10px; } .course-card h6 { font-size: 0.85rem; margin-bottom: 5px; } .course-price { font-size: 0.75rem !important; } .course-card .badge { font-size: 0.6rem; padding: 3px 6px; } .course-card .btn-outline-primary { padding: 2px 10px; font-size: 0.7rem; } 
            .stat-card { padding: 20px 5px; border-radius: 12px; } .stat-icon { width: 45px; height: 45px; font-size: 1.2rem; } .stat-card h3 { font-size: 1.4rem; } 
            .trainer-elite-card { padding: 20px 10px; } .trainer-elite-img { width: 80px; height: 80px; } 
            .test-card { padding: 25px 20px; margin-top: 30px; } .verify-box { padding: 20px; } .toast-container { bottom: 100px; <?php echo ($lang=='ar')?'right':'left'; ?>: 10px; } .custom-toast { width: 300px; padding: 10px 15px; }
            .marquee-wrapper { padding: 15px 0; } .marquee-item { padding: 8px 20px; margin: 0 10px; } .marquee-item span { font-size: 0.95rem; } .marquee-item .flag { font-size: 1.2rem; }
        }
    </style>
</head>
<body>

    <a href="https://wa.me/<?php echo str_replace('+', '', $contact_phone); ?>" class="float-whatsapp" target="_blank" title="<?php echo $t['contact_us']; ?>"><i class="fa-brands fa-whatsapp"></i></a>
    <div class="toast-container" id="toastContainer"></div>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="assets/logo-desktop.png" class="d-none d-md-block" style="height: 60px;" alt="Logo" onerror="this.style.display='none'">
                <img src="assets/logo-mobile.png" class="d-block d-md-none" style="height: 40px;" alt="Logo" onerror="this.style.display='none'"> 
            </a>
            <button class="navbar-toggler border-0 p-1" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon" style="width: 1.5em; height: 1.5em;"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 <?php echo ($lang == 'en') ? 'ms-auto me-0' : ''; ?>">
                    <li class="nav-item"><a class="nav-link active" href="index.php"><?php echo $t['home']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php"><?php echo $t['about']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#courses"><?php echo $t['courses']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#trainers"><?php echo $t['trainers']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#verify"><?php echo $t['verify']; ?></a></li>
                    <li class="nav-item"><a class="nav-link text-warning" href="contact.php"><?php echo $t['contact']; ?></a></li>
                </ul>
                <div class="d-flex align-items-center gap-2 mt-2 mt-lg-0 pb-3 pb-lg-0">
                    <a href="?lang=<?php echo ($lang == 'ar') ? 'en' : 'ar'; ?>" class="text-white fw-bold me-2 text-decoration-none">
                        <i class="fa-solid fa-globe"></i> <?php echo ($lang == 'ar') ? 'EN' : 'عربي'; ?>
                    </a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="login.php" class="btn-solid"><?php echo $t['dashboard']; ?></a>
                    <?php else: ?>
                        <a href="login.php" class="btn-outline"><?php echo $t['login']; ?></a>
                        <a href="register.php" class="btn-solid"><?php echo $t['register']; ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <header class="hero-section">
        <div class="container">
            <h1 class="mb-3"><?php echo $t['hero_title']; ?></h1>
            <p class="lead w-75 mx-auto mb-4"><?php echo $t['hero_desc']; ?></p>
            <a href="#courses" class="btn-solid fs-5 px-4 py-2"><?php echo $t['browse_courses']; ?></a>
        </div>
    </header>

    <!-- 💡 شريط الدول المتحرك الاحترافي المحدث -->
    <div class="marquee-wrapper">
        <div class="marquee-content">
            <?php 
                // مصفوفة الدول المختارة بعناية
                $countries = [
                    ['name' => ($lang == 'ar') ? 'الجزائر' : 'Algeria', 'flag' => '🇩🇿'],
                    ['name' => ($lang == 'ar') ? 'قطر' : 'Qatar', 'flag' => '🇶🇦'],
                    ['name' => ($lang == 'ar') ? 'دبي (الإمارات)' : 'Dubai (UAE)', 'flag' => '🇦🇪'],
                    ['name' => ($lang == 'ar') ? 'تونس' : 'Tunisia', 'flag' => '🇹🇳'],
                    ['name' => ($lang == 'ar') ? 'ماليزيا' : 'Malaysia', 'flag' => '🇲🇾'],
                    ['name' => ($lang == 'ar') ? 'مصر' : 'Egypt', 'flag' => '🇪🇬'],
                ];
                // تكرار المصفوفة 3 مرات لضمان عدم توقف الحركة (Infinite Loop)
                for($i=0; $i<3; $i++) {
                    foreach($countries as $c) {
                        echo '<div class="marquee-item"><span class="flag">'.$c['flag'].'</span><span>'.$c['name'].'</span></div>';
                    }
                }
            ?>
        </div>
    </div>

    <?php if(!empty($promo_date)): ?>
    <section class="promo-banner text-center">
        <div class="container">
            <h3 class="fw-bold mb-2"><?php echo htmlspecialchars($promo_title); ?></h3>
            <p class="mb-0 opacity-75"><?php echo htmlspecialchars($promo_subtitle); ?></p>
            <div class="timer-wrap" id="countdown">
                <div class="time-box"><span id="days">00</span><small><?php echo $t['days']; ?></small></div>
                <div class="time-box"><span id="hours">00</span><small><?php echo $t['hours']; ?></small></div>
                <div class="time-box"><span id="mins">00</span><small><?php echo $t['mins']; ?></small></div>
                <div class="time-box"><span id="secs">00</span><small><?php echo $t['secs']; ?></small></div>
            </div>
            <a href="<?php echo htmlspecialchars($promo_link); ?>" class="btn-solid mt-4 d-inline-block px-5"><?php echo ($lang == 'ar') ? 'سجل الآن' : 'Register Now'; ?></a>
        </div>
    </section>
    <?php endif; ?>

    <!-- ملخص من نحن -->
    <section class="py-5" style="background-color: #fff; position: relative; overflow: hidden; border-top: 1px solid #eee;">
        <div class="container py-4">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 <?php echo ($lang == 'en') ? 'text-start' : ''; ?>">
                    <div class="d-inline-block bg-primary bg-opacity-10 text-primary fw-bold px-3 py-1 rounded-pill mb-3">
                        <i class="fa-solid fa-star text-warning"></i> <?php echo ($lang == 'ar') ? 'نصنع الفرق… لأننا نؤمن بالإنسان' : 'We Make a Difference'; ?>
                    </div>
                    <h2 class="fw-bold mb-4" style="color: var(--primary); line-height: 1.4;">
                        <?php echo ($lang == 'ar') ? 'منارة التمكين والتطوير الإنساني عالمياً' : 'Beacon of Empowerment & Global Development'; ?>
                    </h2>
                    <p class="text-muted lh-lg mb-4 fs-6">
                        <?php echo ($lang == 'ar') ? 'تحت رئاسة <strong>الدكتورة صبيرة حركات</strong>، تنطلق أكاديمية أراميو سمارت العالمية برؤية عالمية ورسالة إنسانية عميقة، لتكون منصة تعليمية رائدة في إعداد الكفاءات، وتأهيل القادة، وتمكين الأفراد.' : 'Under the leadership of Dr. Sabira Harakat, Aramio Smart Global Academy launches with a global vision to be a leading educational platform...'; ?>
                    </p>
                    <a href="about.php" class="btn btn-accent rounded-pill px-5 py-3 fw-bold shadow-sm">
                        <?php echo ($lang == 'ar') ? 'اكتشف أكثر عنا' : 'Discover More About Us'; ?> <i class="fa-solid fa-arrow-<?php echo ($lang == 'ar') ? 'left' : 'right'; ?> ms-2"></i>
                    </a>
                </div>
                <div class="col-lg-6 position-relative d-none d-lg-block">
                    <img src="https://aramiosmartglobal.com/uploads/2.jpg
" class="img-fluid rounded-4 shadow-lg" alt="About Aramio" style="border: 5px solid #fff;">
                </div>
            </div>
        </div>
    </section>

    <section id="courses" class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold" style="color: var(--primary);"><?php echo $t['latest_courses']; ?></h2>
                <div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
            </div>
            <div class="row g-3 g-md-4 justify-content-center">
                <?php foreach($published_courses as $course): ?>
                <div class="col-6 col-lg-3">
                    <div class="card course-card">
                        <img src="<?php echo ($course['thumbnail'] && $course['thumbnail'] != 'default_course.jpg') ? 'uploads/courses/'.$course['thumbnail'] : 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3'; ?>" class="card-img-top course-img" alt="Course">
                        <div class="card-body flex-grow-1 d-flex flex-column">
                            <span class="badge bg-primary mb-1 align-self-start"><?php echo htmlspecialchars($course['category_name'] ?? 'عام'); ?></span>
                            <h6 class="fw-bold mb-2 flex-grow-1"><?php echo htmlspecialchars($course['title_'.$lang] ?? $course['title_ar']); ?></h6>
                            <div class="text-muted small mb-2"><i class="fa-solid fa-user-tie text-primary mx-1"></i> <span class="d-none d-md-inline"><?php echo htmlspecialchars($course['trainer_name']); ?></span></div>
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center border-top pt-2 mt-auto">
                                <span class="fw-bold course-price mb-1 mb-md-0" style="color: var(--primary);">
                                    <?php 
                                        $prices = [];
                                        if($course['price_usd']) $prices[] = '$'.(float)$course['price_usd'];
                                        if($course['price_dzd']) $prices[] = (float)$course['price_dzd'].' د.ج';
                                        echo implode(' <br class="d-md-none"> ', $prices); 
                                    ?>
                                </span>
                                <a href="course.php?id=<?php echo $course['id']; ?>" class="btn btn-outline-primary btn-sm rounded-pill fw-bold"><?php echo $t['course_details']; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-5"><a href="course.php" class="btn btn-outline-primary fw-bold px-5 py-2 rounded-pill" style="border-width: 2px;"><?php echo $t['show_more']; ?> <i class="fa-solid fa-arrow-down mx-1"></i></a></div>
        </div>
    </section>

    <section class="stats-section">
        <div class="container">
            <div class="row justify-content-center g-3">
                <div class="col-6 col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fa-solid fa-book"></i></div>
                        <h3><?php echo (int)$stat_courses; ?></h3>
                        <p class="fw-bold text-muted m-0"><?php echo $t['stats_courses']; ?></p>
                    </div>
                </div>
                <div class="col-6 col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
                        <h3><?php echo (int)$stat_students; ?></h3>
                        <p class="fw-bold text-muted m-0"><?php echo $t['stats_students']; ?></p>
                    </div>
                </div>
                <div class="col-6 col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fa-solid fa-user-tie"></i></div>
                        <h3><?php echo (int)$stat_trainers; ?></h3>
                        <p class="fw-bold text-muted m-0"><?php echo $t['stats_trainers']; ?></p>
                    </div>
                </div>
                <div class="col-6 col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fa-solid fa-comments"></i></div>
                        <h3><?php echo (int)$stat_consultations; ?></h3>
                        <p class="fw-bold text-muted m-0"><?php echo $t['stats_cons']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="trainers" class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold" style="color: var(--primary);"><?php echo $t['trainers_title']; ?></h2>
                <div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
            </div>
            <div class="row justify-content-center g-3 g-md-4">
                <?php foreach($trainers as $trainer): ?>
                <div class="col-6 col-lg-3">
                    <?php 
                        $avatar = ($trainer['avatar'] && $trainer['avatar'] != 'default_avatar.png') ? 'uploads/avatars/'.$trainer['avatar'] : 'https://ui-avatars.com/api/?name='.urlencode($trainer['full_name']).'&background=0b1c3f&color=fff'; 
                        $flag = isset($flags[$trainer['country']]) ? $flags[$trainer['country']] : '🌍'; 
                        $bio_snippet = mb_substr(strip_tags($trainer['bio']), 0, 50) . '...'; 
                    ?>
                    <div class="trainer-elite-card" onclick="showTrainerProfile('<?php echo htmlspecialchars($trainer['full_name'], ENT_QUOTES); ?>', '<?php echo $avatar; ?>', '<?php echo htmlspecialchars($trainer['bio'] ?? 'لا توجد سيرة ذاتية حالياً.', ENT_QUOTES); ?>', '<?php echo $flag; ?>')">
                        <img src="<?php echo $avatar; ?>" class="trainer-elite-img" alt="Trainer">
                        <div class="trainer-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                        <h6 class="fw-bold mb-1" style="color: var(--primary);"><?php echo htmlspecialchars($trainer['full_name']); ?> <span class="trainer-flag"><?php echo $flag; ?></span></h6>
                        <small class="text-muted d-block mb-3" style="font-size: 0.75rem;"><?php echo $bio_snippet; ?></small>
                        <span class="badge bg-light text-primary border rounded-pill px-3">السيرة الذاتية</span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <div class="modal fade" id="trainerProfileModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4" style="border-top: 5px solid var(--accent) !important;">
                <div class="modal-header border-0 pb-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center px-4 pb-5 pt-0">
                    <img id="modalTrainerImg" src="" class="rounded-circle mb-3 shadow" style="width:130px; height:130px; object-fit:cover; border:4px solid #fff; margin-top:-50px;">
                    <h4 class="fw-bold" style="color: var(--primary);"><span id="modalTrainerName"></span> <span id="modalTrainerFlag"></span></h4>
                    <div class="text-warning mb-3"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="badge bg-success bg-opacity-10 text-success rounded-pill px-3 py-2 mb-4"><i class="fa-solid fa-certificate me-1"></i> مدرب و خبير دولي معتمد</p>
                    <div class="bg-light p-3 rounded-3 text-start border">
                        <h6 class="fw-bold text-muted small mb-2"><i class="fa-solid fa-address-card me-1"></i> النبذة المهنية:</h6>
                        <p id="modalTrainerBio" class="text-dark m-0 lh-lg" style="white-space: pre-wrap; font-size:0.95rem;"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 💡 التقييمات الاحترافية (آراء العملاء) -->
    <section id="testimonials" class="py-5" style="background: var(--bg-light); border-top: 1px solid #eee;">
        <div class="container">
            <div class="text-center mb-4">
                <h2 class="fw-bold" style="color: var(--primary);"><?php echo $t['testimonials_title']; ?></h2>
                <div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
            </div>
            <div class="row g-4">
                <?php foreach($testimonials as $test): ?>
                <div class="col-12 col-md-4">
                    <div class="test-card">
                        <div class="text-warning mb-3 fs-5">
                            <?php for($i=1; $i<=$test['rating']; $i++) echo '<i class="fa-solid fa-star"></i>'; ?>
                        </div>
                        <p class="test-text">"<?php echo htmlspecialchars($test['feedback_text']); ?>"</p>
                        
                        <div class="test-client mt-auto">
                            <img src="uploads/testimonials/<?php echo $test['image'] ? $test['image'] : 'default_avatar.png'; ?>" class="test-client-img" alt="Student">
                            <div class="<?php echo ($lang == 'en') ? 'text-start' : 'text-start'; ?>">
                                <h6 class="fw-bold mb-1" style="color: var(--primary);"><?php echo htmlspecialchars($test['student_name']); ?></h6>
                                <small class="text-muted fw-bold"><?php echo htmlspecialchars($test['course_name']); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 💡 معرض صور התقييمات (مرفوعة من الأدمن) -->
    <?php if(!empty($db_reviews)): ?>
    <section class="py-5" style="background: var(--bg-light);">
        <div class="container">
            <div class="swiper reviewsSwiper px-4 pb-4">
                <div class="swiper-wrapper">
                    <?php foreach($db_reviews as $img): ?>
                    <div class="swiper-slide text-center">
                        <img src="uploads/reviews/<?php echo $img; ?>" class="img-fluid rounded-4 shadow-sm border" style="max-height: 400px; object-fit: contain; background: #fff; width: 100%;" alt="Review">
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <section class="py-5 bg-white border-top">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold" style="color: var(--primary);"><i class="fa-solid fa-camera text-primary"></i> <?php echo $t['gallery_title']; ?></h2>
                <div style="width: 60px; height: 4px; background: var(--accent); margin: 10px auto;"></div>
            </div>
            <div class="swiper gallerySwiper px-4">
                <div class="swiper-wrapper">
                    <?php foreach($db_gallery as $img): ?>
                    <div class="swiper-slide">
                        <img src="uploads/gallery/<?php echo $img; ?>" class="img-fluid rounded-4 shadow-sm" style="height: 250px; object-fit: cover; width: 100%; border: 3px solid #fff;" alt="Gallery Image" loading="lazy">
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </section>

    
    
    
    
    
    <!-- 💡 التحقق من الشهادة (مُحدث لدعم الأرشيف والـ QR Scanner) -->
    <section id="verify" class="verify-section text-center" style="background-color: var(--primary); padding: 80px 0;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 verify-box" style="background: rgba(255,255,255,0.05); padding: 40px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.1);">
                    <h3 class="fw-bold mb-3 text-white"><i class="fa-solid fa-certificate text-warning <?php echo ($lang == 'ar') ? 'me-2' : 'ms-2'; ?>"></i> <?php echo $t['verify_title']; ?></h3>
                    <p class="text-white opacity-75 mb-4"><?php echo $t['verify_desc']; ?></p>
                    
                    <form class="d-flex gap-3 flex-column flex-md-row justify-content-center align-items-center mb-4" method="GET" action="index.php#verify">
                        <div class="input-group" style="max-width: 400px; border-radius: 30px; overflow: hidden; box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);">
                            <!-- زر الكاميرا للـ QR -->
                            <button type="button" class="btn btn-light border-0 px-3" onclick="startScanner()" title="مسح QR Code بالكاميرا">
                                <i class="fa-solid fa-qrcode fs-4 text-primary"></i>
                            </button>
                            <input type="text" name="cert_code" id="certInput" class="form-control form-control-lg bg-white border-0 fw-bold text-center text-dark" placeholder="<?php echo $t['verify_placeholder']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-accent px-5 py-3 fw-bold" style="border-radius:30px; background-color: var(--accent) !important; color: white !important; font-size:1.1rem;"><?php echo $t['verify_btn']; ?></button>
                    </form>

                    <!-- حاوية الكاميرا (مخفية افتراضياً) -->
                    <div id="scanner-container" style="display: none; max-width: 300px; margin: 0 auto 20px; border-radius: 15px; overflow: hidden; border: 3px solid var(--accent);">
                        <div id="reader" style="width: 100%;"></div>
                        <button class="btn btn-sm btn-danger w-100 fw-bold rounded-0" onclick="stopScanner()">إغلاق الكاميرا <i class="fa-solid fa-xmark"></i></button>
                    </div>

                    <?php 
                    // 💡 السحر: برمجة التحقق الشامل (من الجدولين: الحديث والقديم الأرشيف)
                    if (isset($_GET['cert_code'])) {
                        $code = trim($_GET['cert_code']);
                        
                        // 1. البحث في الشهادات الجديدة (النظام الحالي)
                        $verify_stmt = $pdo->prepare("
                            SELECT e.certificate_code, e.issue_date, e.grade, u.full_name AS trainee_name, u.country AS trainee_country, c.title_ar AS course_title
                            FROM certificate_exams e
                            JOIN users u ON e.trainee_id = u.id
                            JOIN courses c ON e.course_id = c.id
                            WHERE e.certificate_code = ? AND e.status = 'passed'
                        ");
                        $verify_stmt->execute([$code]);
                        $cert = $verify_stmt->fetch();
                        
                        // 2. إذا لم يجدها، يبحث في أرشيف الشهادات القديمة (Legacy)
                        if (!$cert) {
                            $legacy_stmt = $pdo->prepare("SELECT certificate_code, issue_date, grade, student_name AS trainee_name, nationality AS trainee_country, specialty AS course_title FROM legacy_certificates WHERE certificate_code = ?");
                            $legacy_stmt->execute([$code]);
                            $cert = $legacy_stmt->fetch();
                        }

                        if ($cert) {
                            // عرض الجدول الرسمي
                            $f_name = htmlspecialchars($cert['trainee_name']);
                            $country = htmlspecialchars($cert['trainee_country'] ?: 'غير محدد');
                            $course_name = htmlspecialchars($cert['course_title']);
                            
                            $lbl_success = ($lang == 'ar') ? 'تهانينا! شهادتك صالحة. يرجى الاطلاع أدناه على التفاصيل' : 'Congratulations! Valid Certificate. See details below:';
                            $lbl_fname = ($lang == 'ar') ? 'الاسم الكامل' : 'Full Name';
                            $lbl_nat = ($lang == 'ar') ? 'الجنسية / البلد' : 'Nationality / Country';
                            $lbl_spec = ($lang == 'ar') ? 'التخصص' : 'Specialty';
                            $lbl_grade = ($lang == 'ar') ? 'الدرجة' : 'Grade';
                            $lbl_res = ($lang == 'ar') ? 'النتيجة' : 'Result';
                            $res_val = ($lang == 'ar') ? 'ناجح' : 'Passed';
                            $lbl_id = ($lang == 'ar') ? 'رقم الشهادة' : 'Certificate ID';
                            $lbl_date = ($lang == 'ar') ? 'تاريخ الإصدار' : 'Issue Date';
                            $lbl_help = ($lang == 'ar') ? 'في حال وجود أي استفسار، تواصل معنا عبر' : 'For any inquiries, contact us via';

                            echo '<div class="mt-4 rounded-4 shadow-lg mx-auto overflow-hidden bg-white text-dark" style="max-width: 600px; border: 1px solid #e0e0e0;">
                                    <div class="p-4 text-center" style="background: linear-gradient(135deg, rgba(28, 200, 138, 0.1) 0%, rgba(28, 200, 138, 0.05) 100%); border-bottom: 2px dashed #1cc88a;">
                                        <h4 class="fw-black mb-2" style="color: #0b1c3f;"><i class="fa-solid fa-certificate text-warning me-2"></i> '.$lbl_success.'</h4>
                                        <div class="my-4">
                                            <span class="d-inline-block bg-success text-white fw-black rounded-pill px-4 py-2 fs-4 mb-2 shadow-sm"><i class="fa-solid fa-check-double me-1"></i> '.$res_val.'</span>
                                            <h5 class="fw-bold mt-2" style="color: #0b1c3f;">'.$course_name.'</h5>
                                            <h6 class="fw-bold text-danger m-0">'.$lbl_grade.': '.htmlspecialchars($cert['grade']).'</h6>
                                        </div>
                                    </div>
                                    
                                    <div class="p-4 bg-white text-start">
                                        <div class="row g-3">
                                            <div class="col-6 border-end">
                                                <p class="text-muted small fw-bold mb-1"><i class="fa-solid fa-user text-primary me-1"></i> '.$lbl_fname.'</p>
                                                <h6 class="fw-bold text-dark m-0">'.$f_name.'</h6>
                                            </div>
                                            <div class="col-6">
                                                <p class="text-muted small fw-bold mb-1"><i class="fa-solid fa-earth-americas text-info me-1"></i> '.$lbl_nat.'</p>
                                                <h6 class="fw-bold text-dark m-0">'.$country.'</h6>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="p-3 text-center bg-light border-top">
                                        <div class="d-flex justify-content-around align-items-center mb-3">
                                            <div>
                                                <small class="text-muted d-block fw-bold">'.$lbl_id.'</small>
                                                <span class="badge bg-dark fw-bold fs-6 font-monospace px-3 py-2 rounded-pill"><i class="fa-solid fa-qrcode text-warning me-1"></i> '.$cert['certificate_code'].'</span>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block fw-bold">'.$lbl_date.'</small>
                                                <span class="fw-bold text-dark">'.date('Y-m-d', strtotime($cert['issue_date'])).'</span>
                                            </div>
                                        </div>
                                        <p class="mb-0 fw-bold small" style="color: #0b1c3f;">'.$lbl_help.' <a href="mailto:'.htmlspecialchars($contact_email).'" class="text-decoration-none">'.htmlspecialchars($contact_email).' <i class="fa-regular fa-envelope"></i></a></p>
                                    </div>
                                  </div>';
                        } else {
                            echo '<div class="alert alert-danger mt-4 rounded-pill fw-bold mx-auto shadow-sm" style="max-width: 400px;"><i class="fa-solid fa-triangle-exclamation"></i> '.$t['cert_not_found'].'</div>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <footer class="pt-5 pb-3 text-center text-md-start <?php echo ($lang == 'en') ? 'text-start' : ''; ?>" style="background: var(--primary); color: white; border-top: 4px solid var(--accent);">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-md-5">
                    <h4 class="fw-bold mb-3"><i class="fa-solid fa-graduation-cap mx-2"></i> <?php echo htmlspecialchars($siteName); ?></h4>
                    <p class="small opacity-75 lh-lg pe-md-4"><?php echo $t['hero_desc']; ?></p>
                    <div class="d-flex gap-3 mt-3 justify-content-center justify-content-md-start">
                        <a href="<?php echo htmlspecialchars($fb_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-facebook"></i></a>
                        <a href="<?php echo htmlspecialchars($yt_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-youtube text-danger"></i></a>
                        <a href="<?php echo htmlspecialchars($ig_link); ?>" target="_blank" class="text-white fs-4 opacity-75 text-decoration-none"><i class="fa-brands fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-3">
                    <h6 class="fw-bold mb-3 text-warning"><?php echo $t['quick_links']; ?></h6>
                    <ul class="list-unstyled small opacity-75 lh-lg">
                        <li><a href="about.php" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['about']; ?></a></li>
                        <li><a href="#courses" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['courses']; ?></a></li>
                        <li><a href="#verify" class="text-white text-decoration-none"><i class="fa-solid fa-angle-<?php echo ($lang=='ar')?'left':'right'; ?> mx-1"></i> <?php echo $t['verify']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3 text-warning"><?php echo $t['contact_us']; ?></h6>
                    <p class="small opacity-75 mb-2" dir="ltr"><i class="fa-solid fa-envelope text-accent mx-2"></i> <?php echo htmlspecialchars($contact_email); ?></p>
                    <p class="small opacity-75 mb-0" dir="ltr"><i class="fa-solid fa-phone text-accent mx-2"></i> <span dir="ltr"><?php echo htmlspecialchars($contact_phone); ?></span></p>
                </div>
            </div>
            <div class="border-top border-light border-opacity-10 pt-3 mt-4 small opacity-75 d-flex flex-column flex-md-row justify-content-between align-items-center">
                <p class="mb-2 mb-md-0">&copy; <?php echo date('Y'); ?> <?php echo $t['rights']; ?> - <?php echo htmlspecialchars($siteName); ?>.</p>
                <div class="fs-5 d-flex gap-3 text-white opacity-50">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script>
      var swiper1 = new Swiper(".gallerySwiper", { slidesPerView: 1, spaceBetween: 15, loop: true, autoplay: { delay: 2500, disableOnInteraction: false }, navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" }, breakpoints: { 640: { slidesPerView: 2, spaceBetween: 20 }, 768: { slidesPerView: 3, spaceBetween: 30 }, 1024: { slidesPerView: 4, spaceBetween: 30 } } });
      var swiper2 = new Swiper(".reviewsSwiper", { slidesPerView: 1, spaceBetween: 20, loop: true, autoplay: { delay: 3500, disableOnInteraction: false }, pagination: { el: ".swiper-pagination", clickable: true }, breakpoints: { 640: { slidesPerView: 2, spaceBetween: 20 }, 1024: { slidesPerView: 3, spaceBetween: 30 } } });
    </script>
    <script>
        const popups = <?php echo json_encode($popups); ?>;
        const popupDelay = <?php echo getSetting($pdo, 'popup_timer') ?: '10'; ?> * 1000;
        let popupIndex = 0;
        function showNextPopup() {
            if(popups.length === 0) return;
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = 'custom-toast';
            const dirClass = '<?php echo ($lang == "en") ? "text-start" : ""; ?>';
            toast.innerHTML = `<div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; min-width: 40px;"><i class="fa-solid fa-bell"></i></div><div class="${dirClass} w-100"><p class="mb-0 fw-bold text-dark small lh-base">${popups[popupIndex]}</p><small class="text-muted" style="font-size: 0.7rem;"><?php echo $t['now']; ?></small></div>`;
            container.appendChild(toast);
            setTimeout(() => { toast.classList.add('show'); }, 100);
            setTimeout(() => { toast.classList.remove('show'); setTimeout(() => { toast.remove(); }, 500); }, 5000);
            popupIndex = (popupIndex + 1) % popups.length;
        }
        if(popups.length > 0) { setTimeout(() => { showNextPopup(); setInterval(showNextPopup, popupDelay); }, 3000); }
    </script>
    <?php if(!empty($promo_date)): ?><script>var countDownDate = new Date("<?php echo $promo_date; ?>").getTime(); var x = setInterval(function() { var now = new Date().getTime(); var distance = countDownDate - now; document.getElementById("days").innerHTML = Math.floor(distance / (1000 * 60 * 60 * 24)); document.getElementById("hours").innerHTML = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)); document.getElementById("mins").innerHTML = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)); document.getElementById("secs").innerHTML = Math.floor((distance % (1000 * 60)) / 1000); if (distance < 0) { clearInterval(x); document.getElementById("countdown").innerHTML = "<h4 class='text-white m-0'><?php echo $t['ended']; ?></h4>"; } }, 1000);</script><?php endif; ?>
    <script>function showTrainerProfile(name, avatar, bio, flag) { document.getElementById('modalTrainerName').innerText = name; document.getElementById('modalTrainerImg').src = avatar; document.getElementById('modalTrainerBio').innerText = bio; document.getElementById('modalTrainerFlag').innerText = flag; new bootstrap.Modal(document.getElementById('trainerProfileModal')).show(); }</script>

    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- 💡 مكتبة مسح الـ QR Code من الكاميرا -->
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        let html5QrcodeScanner;
        
        function startScanner() {
            document.getElementById('scanner-container').style.display = 'block';
            if (!html5QrcodeScanner) {
                html5QrcodeScanner = new Html5QrcodeScanner(
                    "reader", { fps: 10, qrbox: 250 });
                html5QrcodeScanner.render(onScanSuccess, onScanError);
            }
        }
        
        function stopScanner() {
            if (html5QrcodeScanner) {
                html5QrcodeScanner.clear();
                html5QrcodeScanner = null;
            }
            document.getElementById('scanner-container').style.display = 'none';
        }
        
        function onScanSuccess(decodedText, decodedResult) {
            // عند التقاط الـ QR، يتم كتابة الكود في المربع وإغلاق الكاميرا وإرسال الفورم تلقائياً!
            document.getElementById('certInput').value = decodedText;
            stopScanner();
            document.forms[0].submit(); // افتراض أن فورم البحث هو الأول
        }
        
        function onScanError(errorMessage) { /* لا نفعل شيئاً حتى يقرأ الكود الصحيح */ }
    </script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </body>
</html>