<?php
// استدعاء الاتصال بقاعدة البيانات
require_once 'includes/init.php'; // تأكد أن مسار ملف الاتصال صحيح

// قائمة الخبراء
$experts = [
    ['أحلام بن ساسي', 'ahlam@aramiosmartglobal.com', 'الجزائر'],
    ['أمال حضري حميدة', 'amal@aramiosmartglobal.com', 'الجزائر'],
    ['ليلى شويخة', 'laila@aramiosmartglobal.com', 'تونس'],
    ['عائدة شويخة', 'aida@aramiosmartglobal.com', 'تونس'],
    ['زوليخة لحسين', 'zoulikha@aramiosmartglobal.com', 'الجزائر'],
    ['مبارك حجاجي', 'mubarak@aramiosmartglobal.com', 'الجزائر'],
    ['مبروك السيار', 'mabrouk@aramiosmartglobal.com', 'تونس'],
    ['فضيلة موكاح', 'fadhila@aramiosmartglobal.com', 'الجزائر'],
    ['زوبير سالم', 'zoubir@aramiosmartglobal.com', 'الجزائر'],
    ['رميلة نمديلي', 'romaila@aramiosmartglobal.com', 'الجزائر'],
    ['خيرة حشايشي', 'khaira@aramiosmartglobal.com', 'الجزائر'],
    ['عزيزة سالم', 'aziza@aramiosmartglobal.com', 'الجزائر']
];

// كلمة السر الموحدة (يتم تشفيرها لكي يقبلها نظام تسجيل الدخول الخاص بك)
$plain_password = 'Aramio@2026';
$hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

$count = 0;

try {
    foreach ($experts as $expert) {
        // التحقق لعدم تكرار الإيميل إذا ضغطت على الرابط مرتين
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$expert[1]]);
        
        if ($check->rowCount() == 0) {
            // إدخال العميل برتبة (مدرب / خبير) وتفعيل حسابه مباشرة
            $insert = $pdo->prepare("INSERT INTO users (full_name, email, password, country, is_verified, role, status) VALUES (?, ?, ?, ?, 1, 'trainer', 1)");
            $insert->execute([$expert[0], $expert[1], $hashed_password, $expert[2]]);
            $count++;
        }
    }
    
    echo "<h1 style='color:green; text-align:center; margin-top:50px;'>تم إنشاء {$count} حسابات بنجاح! 🎉</h1>";
    echo "<h2 style='text-align:center;'>كلمة السر لجميع الحسابات هي: <b>{$plain_password}</b></h2>";
    echo "<p style='text-align:center; color:red;'>ملاحظة أمنية هامة: يرجى حذف هذا الملف (add_experts.php) من الاستضافة الآن.</p>";

} catch (Exception $e) {
    echo "حدث خطأ: " . $e->getMessage();
}
?>