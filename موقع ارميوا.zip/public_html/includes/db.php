<?php
// إعدادات الاتصال بقاعدة البيانات على الاستضافة المدفوعة
$host = 'localhost'; // تم التعديل هنا (هذا هو السيرفر الصحيح لـ Hostinger)
$db   = 'u846492886_a';
$user = 'u846492886_a';      
$pass = 'AAAaaa@1303';          
$charset = 'utf8mb4'; // الترميز الشامل للغة العربية والإيموجي

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    
    // إجبار القاعدة على استقبال وإرسال البيانات بالعربية فور الاتصال
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    // يمكنك إزالة علامة التعليق (//) عن السطر التالي لتجربة الاتصال، وإذا ظهرت لك كلمة "تم الاتصال" قم بمسحه
    // echo "تم الاتصال بقاعدة البيانات بنجاح!"; 
} catch (\PDOException $e) {
    // إيقاف الموقع وإظهار رسالة خطأ واضحة في حال فشل الاتصال
    die('فشل الاتصال بقاعدة البيانات: ' . $e->getMessage());
}
?>