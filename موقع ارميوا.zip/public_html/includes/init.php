<?php
session_start();

// استدعاء الاتصال بقاعدة البيانات
require_once 'db.php';

// ==========================================
// 1. نظام تعدد اللغات (العربية / الإنجليزية)
// ==========================================
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] == 'en') ? 'en' : 'ar';
}
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'ar'; // العربية هي الافتراضية
}
$dir = ($_SESSION['lang'] == 'ar') ? 'rtl' : 'ltr';

// ==========================================
// 2. نظام العملات
// ==========================================
if (isset($_GET['currency'])) {
    $_SESSION['currency'] = ($_GET['currency'] == 'DZD') ? 'DZD' : 'USD';
}
if (!isset($_SESSION['currency'])) {
    $_SESSION['currency'] = 'USD'; // الدولار هو الافتراضي
}

// دالة سحرية لتحويل وعرض السعر
function formatPrice($usd_price) {
    $exchange_rate = 135; 
    if ($_SESSION['currency'] == 'DZD') {
        $dzd_price = $usd_price * $exchange_rate;
        return number_format($dzd_price, 0) . ' د.ج';
    } else {
        return '$' . number_format($usd_price, 2);
    }
}

// ==========================================
// 3. دوال جلب الإعدادات من قاعدة البيانات (تم التحديث لمنع الاختفاء)
// ==========================================
function getSetting($pdo, $key, $lang = 'ar') {
    $stmt = $pdo->prepare("SELECT setting_value_ar, setting_value_en FROM settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    
    if ($result) {
        // إذا طلبنا الإنجليزي وكان فارغاً، اجلب العربي كاحتياطي (Fallback) لكي لا يختفي النص
        $val = $result["setting_value_$lang"];
        return !empty($val) ? $val : $result['setting_value_ar'];
    }
    return '';
}

// جلب الإعدادات الأساسية لكي تُقرأ في كل الصفحات
$siteName = getSetting($pdo, 'site_name', $_SESSION['lang']) ?: 'Aramio Academy';
$contact_email = getSetting($pdo, 'contact_email', $_SESSION['lang']) ?: 'info@aramio.com';
$contact_phone = getSetting($pdo, 'phone_number', $_SESSION['lang']) ?: '+000000000';
?>