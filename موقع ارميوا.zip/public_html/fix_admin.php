<?php
// استدعاء الاتصال بقاعدة البيانات
require_once 'includes/db.php';

// بيانات الدخول التي نريدها
$email = 'admin@aramio.com';
$password = '123456';

// تشفير كلمة المرور باستخدام خادمك المحلي لضمان التوافق
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

try {
    // 1. مسح أي حساب مدير قديم يحمل نفس الإيميل لتجنب التكرار
    $delete = $pdo->prepare("DELETE FROM users WHERE email = ?");
    $delete->execute([$email]);

    // 2. إدخال الحساب الجديد بصلاحيات admin
    $insert = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES ('المدير العام', ?, ?, 'admin')");
    $insert->execute([$email, $hashed_password]);

    echo "<div style='text-align:center; margin-top:50px; font-family:tahoma;'>";
    echo "<h2 style='color:green;'>✅ تم إصلاح حساب الإدارة بنجاح!</h2>";
    echo "<p><strong>الإيميل:</strong> admin@aramio.com</p>";
    echo "<p><strong>كلمة المرور:</strong> 123456</p>";
    echo "<br><a href='login.php' style='padding:10px 20px; background:blue; color:white; text-decoration:none;'>اذهب لصفحة الدخول</a>";
    echo "</div>";

} catch(PDOException $e) {
    echo "حدث خطأ: " . $e->getMessage();
}
?>