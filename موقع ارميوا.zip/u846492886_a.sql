-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 11, 2026 at 04:11 AM
-- Server version: 11.8.9-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u846492886_a`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name_ar` varchar(150) NOT NULL,
  `name_en` varchar(150) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_ar`, `name_en`, `status`, `created_at`) VALUES
(1, 'ملتقيات دولية', 'International forums', 1, '2026-03-25 07:21:55'),
(2, 'إستشارة', 'consultation', 1, '2026-03-27 13:58:04'),
(3, 'دورة عامة', 'General course', 1, '2026-03-27 13:58:46');

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `id` int(11) NOT NULL,
  `trainee_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `certificate_code` varchar(50) NOT NULL,
  `issue_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `certificate_exams`
--

CREATE TABLE `certificate_exams` (
  `id` int(11) NOT NULL,
  `trainee_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `exam_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `grade` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected','passed') DEFAULT 'pending',
  `certificate_code` varchar(50) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificate_exams`
--

INSERT INTO `certificate_exams` (`id`, `trainee_id`, `course_id`, `trainer_id`, `exam_date`, `notes`, `grade`, `status`, `certificate_code`, `issue_date`, `created_at`) VALUES
(1, 5, 2, 4, '2026-04-01', '???????', 'جيد', 'passed', 'AR-77FFFFD6-26', '2026-03-26', '2026-03-26 13:24:59'),
(2, 5, 4, 4, '2026-03-27', '', 'مقبول', 'passed', 'AR-2663809C-26', '2026-03-27', '2026-03-27 14:04:44');

-- --------------------------------------------------------

--
-- Table structure for table `consultation_bookings`
--

CREATE TABLE `consultation_bookings` (
  `id` int(11) NOT NULL,
  `trainee_id` int(11) NOT NULL,
  `trainee_problem` text DEFAULT NULL,
  `availability_id` int(11) NOT NULL,
  `amount_usd` decimal(10,2) DEFAULT NULL,
  `amount_dzd` decimal(10,2) DEFAULT NULL,
  `payment_method` enum('bank','paypal','agent') NOT NULL DEFAULT 'bank',
  `receipt_image` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected','completed','reserved','canceled') DEFAULT 'pending',
  `meeting_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `consultation_bookings`
--

INSERT INTO `consultation_bookings` (`id`, `trainee_id`, `trainee_problem`, `availability_id`, `amount_usd`, `amount_dzd`, `payment_method`, `receipt_image`, `status`, `meeting_link`, `created_at`) VALUES
(2, 5, 'اريد استشارة', 2, NULL, 5000.00, 'bank', '1774563367_246.png', 'approved', NULL, '2026-03-26 22:15:19');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `full_name`, `email`, `phone`, `message`, `is_read`, `created_at`) VALUES
(4, 'Danielgal', 'info@onyxservices.com.au', '89211695374', 'The $27,000,000 Jackpot Is a Spark for Something Greater https://gnosis.link/lZVRk', 0, '2026-07-02 21:24:36'),
(5, 'Ken McKenny', 'kenp2025x@yahoo.com', '', 'Was just browsing aramiosmartglobal.com and was impressed the layout. Nicely design and great user experience. Just had to drop a message, have a great day! we7f8sd82', 0, '2026-07-03 02:51:51'),
(6, 'Joanna Riggs', 'joriggsvideo3@gmail.com', '2253704209', 'Hi,\r\n\r\nI just visited aramiosmartglobal.com and wondered if you\'ve ever considered an impactful video to advertise your business? Our videos can generate impressive results on both your website and across social media.\r\n\r\nOur prices start from just $195 (USD).\r\n\r\nLet me know if you\'re interested in seeing samples of our previous work.\r\n\r\nRegards,\r\nJoanna\r\n\r\nUnsubscribe: https://unsubscribe.video/unsubscribe.php?d=aramiosmartglobal.com', 0, '2026-07-08 14:58:22'),
(7, 'Roy Heinrich Smith', 'baseoffice11@gmail.com', '84646377571', 'My name is Roy Heinrich Smith, I am a research head with Hamilton Laboratory UK known for vast manufacturing. \r\nI am reaching out to discuss a promising business opportunity that could be highly advantageous for both of us. I need a dependable foreign business partner to assist me in procuring a rare Premium Herbal Extract known as Kolmogorovian HG57. \r\nAlthough this may not fall within your usual area of expertise, it presents an opportunity for an additional revenue stream for you or your organization. The limited availability of this raw material has impeded product development at my company. Our previous supplier in Ukraine has ceased operations due to the ongoing conflict in the region. \r\nPROPOSAL: I am requesting your agreement to act as a new contractor between the manufacturer and Hamilton Laboratory to facilitate this project/contract. \r\nWe would share the profits from this venture, with 80% allocated to you and 20% to me. I am unable to bid for the supply contract myself, as I prefer to avoid direct contact between my company and the manufacturer, which also falls outside the scope of my employment contract. \r\nPlease respond to this email heinrichgunter50@gmail.com l so that I can provide you with further details regarding the process. \r\nI look forward to establishing a mutually beneficial partnership. \r\nKind regards, \r\nRoy Heinrich Smith G. \r\nResearch & Development Department \r\nDurham Pharmaceuticals Limited', 0, '2026-07-13 16:14:28'),
(8, 'kolca_ylPi', 'mqfjkvusjPi@vseindi.com', '82633354622', 'Подарите своей возлюбленной незабываемое впечатление — выберите <a href=https://www.rings-diamond.ru/>кольцо из белого золота с бриллиантом</a> и сделайте предложение, которое запомнится на всю жизнь. \r\nЗатем обсуждается стиль и символика кольца.', 0, '2026-07-16 17:57:16'),
(9, 'Mishra', 'anaya.dgtlsolution@gmail.com', '', 'Hello there,\r\n\r\nI recently came across http://www.aramiosmartglobal.com and wanted to get in touch. Your website has good potential, and with the right SEO strategy, it could reach more customers through Google.\r\n\r\nOur SEO services are customized to improve rankings, increase organic traffic, and help businesses generate consistent leads.\r\n\r\nIf this is something you\'d be interested in, let me know, and I\'ll send our SEO strategies along with our package details.\r\n\r\nBest regards,\r\nAnaya', 0, '2026-07-17 05:55:02'),
(10, 'Alina', 'alinajoshi.mkt@gmail.com', '', 'Hello https://aramiosmartglobal.com/contact,\r\n\r\nWhile browsing your website, I noticed some optimization issues that\r\ncould be limiting your organic traffic.\r\n\r\nI’ve put together a quick audit report with screenshots.\r\n\r\nLet me know if you\'d like to see it.\r\n\r\nThank You,\r\nAlina', 0, '2026-07-21 15:50:52'),
(11, 'HarryDaype', 'karro_lina@hotmail.com', '81518394659', 'ETHEREUM GAS FEES OPTIMIZING FOR $1,500 PER DAY OR MORE SAVINGS https://telegra.ph/Collect-cryptocurrency-automatically-every-day-over-1500-Message-ID-338019-07-23', 0, '2026-07-28 20:16:27'),
(12, 'Mishra', 'anaya.dgtlsolution@gmail.com', '', 'Hello there,\r\n\r\nI recently came across https://www.aramiosmartglobal.com/ and wanted to get in touch. Your website has good potential, and with the right SEO strategy, it could reach more customers through Google.\r\n\r\nOur SEO services are customized to improve rankings, increase organic traffic, and help businesses generate consistent leads.\r\n\r\nIf this is something you\'d be interested in, let me know, and I\'ll send our SEO strategies along with our package details.\r\n\r\nBest regards,\r\nAnaya', 0, '2026-07-29 16:19:12'),
(13, '1hslot_xgOt', 'equtlozpxOt@vseindi.com', '84866349455', 'Проверить актуальные ссылки и скачать приложение можно по ссылке: <a href=https://1xslots-skachat1.ru/>скачать 1xslots на андроид мобильная версия</a>. \r\nПользователи могут заранее ознакомиться с требованиями по вейджеру и другими ограничениями.', 0, '2026-07-31 14:45:13'),
(14, 'Alina', 'alinasale.inbox@gmail.com', '', 'Hello https://aramiosmartglobal.com/,\r\n\r\nA quick follow-up.\r\n\r\nIf improving your Google visibility is something you\'re considering, I\'d be happy to send you a free SEO report and our package details.\r\n\r\nJust let me know.\r\n\r\nThank you!\r\nAlina', 0, '2026-08-04 02:47:46'),
(15, 'Jill Rhodes', 'sales@aramiosmartglobal.com', '4354882137', 'Hey there \r\n\r\nLooking to improve your posture and live a healthier life? Our Medico Postura™ Body Posture Corrector is here to help!\r\n\r\nExperience instant posture improvement with Medico Postura™. This easy-to-use device can be worn anywhere, anytime – at home, work, or even while you sleep.\r\n\r\nMade from lightweight, breathable fabric, it ensures comfort all day long.\r\n\r\nGrab it today at a fantastic 60% OFF: https://medicopostura.com\r\n\r\nPlus, enjoy FREE shipping for today only!\r\n\r\nDon\'t miss out on this amazing deal. Get yours now and start transforming your posture!\r\n\r\nThanks and Best Regards, \r\n\r\nJill', 0, '2026-08-10 01:51:03'),
(16, 'Arpit Mishra', 'arpit.dgtlsolution@gmail.com', '3636066324', 'Hi, \r\n\r\nI hope you’re doing well.\r\n\r\nI wanted to reach out and see if you are interested in improving your website’s http://aramiosmartglobal.com visibility on Google and attracting more potential customers through SEO. We offer SEO solutions designed to help businesses increase organic traffic, improve keyword rankings, and generate quality inquiries.\r\n\r\nIf this sounds interesting, I’d be happy to share our complete SEO packages, activities, timeline, and pricing details for your review.\r\n\r\nLooking forward to your response.\r\n\r\nRegards,\r\nArpit', 0, '2026-08-14 17:00:17'),
(17, 'true_yzmr', 'aelyukqlsmr@bystriy324andy.site', '82331337413', 'Been playing at true fortune casino around six months back after someone in another thread banged on about it, and honestly I reckoned it\'d be just another cookie-cutter places that disappear after a month. Still here though, so that says something I suppose. \r\n \r\nGame selection is properly stacked — I\'d guess around 2,000 titles going by the counter. NetEnt take up most of the front page, so expect the ones everyone plays — Sweet Bonanza gets the bulk of my spins, and there\'s decent runs on Betsoft stuff too. Microgaming older titles are hidden behind the filters but they exist. \r\n \r\nThe live rooms are all Evolution from what I\'ve seen, and that\'s about as good as it gets. Crazy Time and Monopoly Live draw proper numbers in the evenings, croupiers are friendly enough and it doesn\'t stutter on 4G. The welcome side was around 100% plus and 100 free spins, wagering is 30x which isn\'t amazing but isn\'t a scam either. There was a no deposit spins offer at one point too; terms change often so it\'s worth a read the current ones over on <a href=https://innerlighthouseapp.com/>true fortune</a> rather than trusting my memory. \r\n \r\nYou can get in from a tenner if memory serves, verification took two minutes plus KYC. Visa is what I use, Skrill and Neteller are the fast option and there\'s Bitcoin as well if that\'s your thing. Payouts on my card came through in a day and a bit, bank transfer dragged to three days. \r\n \r\nWhat did irritate me: the verification wanted a second utility bill, which delayed a withdrawal for about 48 hours. Support fixed it eventually but it took two goes. They\'re licensed and that mattered to me, and that\'s the first thing I check now. \r\n \r\nThere\'s no dedicated app on the Play Store, the responsive site does the job — runs smooth on a knackered old Samsung, but scrolling the lobby is a chore on mobile. Still got a balance sat there, so says more than a rating would.', 0, '2026-08-17 13:12:10'),
(18, 'reyting_ssPi', 'smceqtbvaPi@lilycake.ru', '84635635418', 'В нашей новой статье вы найдете <a href=https://media-garage.ru/moya-kollekciya/rejting-sistemnyh-multimedia-integratorov-goroda-moskvy>рейтинг системных интеграторов</a>, который поможет выбрать лучшего подрядчика для вашего проекта. \r\nОсобенно ценятся кейсы, где интеграторы решали задачи по объединению нескольких подсистем и нестандартным требованиям. \r\n \r\nСпин-шаблон: \r\nВажны регулярные программные обновления, обучающие программы для заказчика и качество технической документации.', 0, '2026-08-18 22:35:17'),
(19, 'karkasnyy_vgOl', 'bvwzljfvxOl@lilycake.ru', '83143112152', 'Если вы планируете строительство жилья, обратите внимание на <a href=https://karkasnye-doma-pod-klyuch13.ru>каркасный дом</a> — это современное и экономичное решение для комфортного проживания. \r\nРаботы на строительной площадке занимают меньше времени благодаря заводской подготовке элементов.', 0, '2026-08-21 22:56:57'),
(20, 'karkasnyy_yvOl', 'gmtonzkyzOl@lilycake.ru', '85236957224', 'Если вы планируете строительство жилья, обратите внимание на <a href=https://karkasnye-doma-pod-klyuch13.ru>дома каркасные спб</a> — это современное и экономичное решение для комфортного проживания. \r\nВ итоге владельцы могут экономить деньги и быстрее использовать своё жилье.', 0, '2026-08-24 13:14:52'),
(21, 'karkasnyy_udOl', 'zvhjrssraOl@lilycake.ru', '85391158564', 'Если вы планируете строительство жилья, обратите внимание на <a href=https://karkasnye-doma-pod-klyuch13.ru>каркасные дома спб</a> — это современное и экономичное решение для комфортного проживания. \r\nЭтот фактор достигается из-за предварительной сборки конструктивных элементов на производстве.', 0, '2026-08-27 04:27:24'),
(22, 'mehaniches_qvkt', 'pzoteprhlkt@lilycake.ru', '89872344757', 'Для надежной защиты участка отлично подойдут <a href=https://www.vorota-otkatnyye-mekhanicheskiye-na-rolikakh.ru/>механические откатные ворота для дачи цена</a>. \r\nПри желании конструкцию нетрудно оснастить приводом, чтобы управление стало еще проще.', 0, '2026-08-29 17:45:28'),
(23, 'kursy_urKn', 'kipnffwadKn@lilycake.ru', '83913891396', 'Если вы хотите быстро и эффективно освоить новый язык, выбирайте <a href=https://kursyispanskogo1.ru/>языковая школа испанского</a>, где обучение построено удобно и результативно. \r\nВо время обучения появляется четкий план и постоянная языковая тренировка. \r\n \r\nСтуденты повторяют фразы, составляют диалоги и учатся понимать живую речь. \r\n \r\nДаже при небольшом опыте можно быстро войти в ритм и почувствовать прогресс. \r\n \r\nЕсли программа выбрана удачно, занятия становятся интересными и эффективными.', 0, '2026-09-02 15:13:53'),
(24, 'Maple Gollan', 'sales@aramiosmartglobal.com', '383787149', 'Hey \r\n\r\nI wanted to reach out and let you know about our new dog harness. It\'s really easy to put on and take off - in just 2 seconds - and it\'s personalized for each dog. \r\nPlus, we offer a lifetime warranty so you can be sure your pet is always safe and stylish.\r\n\r\nWe\'ve had a lot of success with it so far and I think your dog would love it. \r\n\r\nGet yours today with 50% OFF: https://caredogbest.com\r\n\r\nFREE Shipping - TODAY ONLY! \r\n\r\nTo your success, \r\n\r\nMaple', 0, '2026-09-04 22:31:17'),
(25, 'kursy_ebKn', 'yszbyjwzjKn@lilycake.ru', '83213613396', 'Если вы хотите быстро и эффективно освоить новый язык, выбирайте <a href=https://kursyispanskogo1.ru/>курсы по испанскому языку</a>, где обучение построено удобно и результативно. \r\nОн полезен в поездках, в деловой среде и в повседневных разговорах. \r\n \r\nСтуденты повторяют фразы, составляют диалоги и учатся понимать живую речь. \r\n \r\nЭто делает обучение доступным для студентов, специалистов и родителей. \r\n \r\nИспанский язык со временем становится не абстрактной целью, а реальным преимуществом.', 0, '2026-09-05 12:37:29'),
(26, '1hslot_xjMt', 'segwjcducMt@vseindi.com', '82949783485', 'На сайте <a href=https://1xslots-skachat01.ru/>скачать 1х слот</a> можно быстро найти удобное приложение для игры на Android. \r\nПользователю легко освоить основные разделы, даже если он впервые открывает сервис. \r\n \r\nВо втором разделе важно отметить, что 1хслот делает акцент на стабильной работе и понятной структуре. Пользователь быстро находит нужные элементы и не сталкивается с лишней сложностью. Это особенно удобно, когда важны скорость и предсказуемость. \r\n \r\nЕще один плюс заключается в том, что сервис старается сохранять баланс между простотой и функциональностью. Пользователь получает достаточно инструментов, чтобы чувствовать уверенность в процессе. При этом навигация остается легкой и не перегружает внимание. \r\n \r\nТакой подход особенно удобен, когда на первом месте стоят скорость и предсказуемость. \r\n \r\nТретий раздел помогает понять, почему 1хслот часто рассматривают как практичное решение для регулярного использования. Удобство здесь сочетается с быстрым доступом к основным возможностям. Это создает ощущение простоты и контроля. \r\n \r\nКроме того, платформа подходит тем, кто предпочитает ясные сценарии без долгого освоения. Важные функции расположены логично, поэтому пользователь не тратит время на поиск. Такой формат особенно ценят те, кто любит порядок и четкую структуру. \r\n \r\nТакже платформа подходит тем, кто выбирает ясные сценарии без долгого освоения. \r\n \r\nВ четвертом разделе можно сказать, что 1хслот формирует комфортную среду для тех, кто хочет получать понятный пользовательский опыт. Здесь нет ощущения хаоса, а каждый шаг выглядит логичным. Именно поэтому платформа вызывает интерес у широкой аудитории. \r\n \r\nЕсли вам важны простота, скорость и удобство, 1хслот выглядит достойным вариантом. Платформа не усложняет путь пользователя и помогает сосредоточиться на главном. За счет этого она остается привлекательной для разных категорий пользователей. \r\n \r\nМожно сказать, что 1хслот формирует комфортную среду для тех, кто хочет получать понятный пользовательский опыт.', 0, '2026-09-06 00:14:53'),
(27, 'Aman Katiyar', 'aman@rocketdigitaltech.com', '9135881851', 'Hello http://aramiosmartglobal.com,\r\n\r\nWe can place your website on Google 1st page.\r\n\r\nI can give you our Complete SEO Action Plan along with a customary reach and add great value to your product/ service.\r\n\r\nI may send you a SEO Packages & price list. If interested.\r\n\r\nBest Regards,\r\nAman\r\nOnline SEO Consultant', 0, '2026-09-06 22:51:28'),
(28, 'Remont_tkSn', 'yqcqpxjcnSn@lilycake.ru', '89178851896', '<a href=https://remont-dvig124.ru>Двигатель капремонт</a> — доверьте восстановление двигателя автомобиля опытным специалистам. \r\nПравильная диагностика позволяет рационально использовать бюджет и сохранить рабочие компоненты. \r\n \r\nОсновные этапы ремонта \r\n \r\nКаждая процедура проводится с учетом конструкции и параметров определенного силового агрегата. \r\n \r\nСборка и проверка \r\n \r\nМастера контролируют давление масла, температуру, уровень шума и стабильность работы. \r\n \r\nПрофилактика и обслуживание \r\n \r\nЕсли появились первые симптомы поломки, стоит сразу посетить квалифицированную мастерскую.', 0, '2026-09-07 18:29:53'),
(29, 'eko_pdsl', 'dfdtzpynzsl@vseindi.com', '87214424237', 'Узнайте, как оформить процедуру <a href=https://reproductiveclinic.ru/>что входит в омс по эко</a> и получить квалифицированную помощь специалистов. \r\nПрограмма действует в рамках государственной системы обязательного медицинского страхования. \r\n \r\nКак проходит подготовка к процедуре \r\n \r\nПосле сбора документов медицинская комиссия изучает историю лечения и подтверждает наличие показаний. \r\n \r\nЧто входит в лечение \r\n \r\nНекоторые препараты, дополнительные анализы или услуги могут потребовать самостоятельной оплаты. \r\n \r\nПрактические рекомендации пациентам \r\n \r\nЕсли появляются спорные вопросы, стоит запросить письменный ответ у медицинской организации.', 0, '2026-09-08 07:12:47'),
(30, 'Anaya Mishra', 'anaya.dgtlsolution@gmail.com', '4622374', 'Hi there, \r\n\r\nI hope you’re doing well.\r\n\r\nI wanted to reach out and see if you are interested in improving your website’s http://aramiosmartglobal.com visibility on Google and attracting more potential customers through SEO. We offer SEO solutions designed to help businesses increase organic traffic, improve keyword rankings, and generate quality inquiries.\r\n\r\nIf this sounds interesting, I’d be happy to share our complete SEO packages, activities, timeline, and pricing details for your review.\r\n\r\nLooking forward to your response.\r\n\r\nRegards,\r\nAnaya', 0, '2026-09-08 10:18:41'),
(31, 'Alina', 'alinasale.inbox@gmail.com', '', 'Hello http://aramiosmartglobal.com,\r\n\r\nIf you’re looking to rank higher on Google and attract more customers, we can help.\r\n\r\nOur customized SEO plan focuses on keywords, backlinks, and content to boost your results.\r\n\r\nReply to receive our proposal and quotation.\r\n\r\nKind Regards,\r\nAlina', 0, '2026-09-09 09:08:18'),
(32, 'Remont_rjSn', 'ofapegzcySn@lilycake.ru', '87942929481', '<a href=https://remont-dvig124.ru>Ремонт двс</a> — доверьте восстановление двигателя автомобиля опытным специалистам. \r\nРемонт двигателя начинается с тщательной диагностики. \r\n \r\nОсновные этапы ремонта \r\n \r\nДетали тщательно очищают, после чего оценивают их состояние и степень износа. \r\n \r\nСборка и проверка \r\n \r\nТолько после успешных испытаний автомобиль передают владельцу. \r\n \r\nПрофилактика и обслуживание \r\n \r\nПродлить срок службы двигателя помогает регулярное техническое обслуживание.', 0, '2026-09-09 13:46:29'),
(33, 'Mandy Lovely', 'sales@lovely.bangeshop.com', '7854182748', 'Hello there, \r\n\r\nI hope this email finds you well. I wanted to let you know about our new BANGE backpacks and sling bags that just released.\r\n\r\nBange is perfect for students, professionals and travelers. The backpacks and sling bags feature a built-in USB charging port, making it easy to charge your devices on the go.  Also they are waterproof and anti-theft design, making it ideal for carrying your valuables.\r\n\r\nBoth bags are made of durable and high-quality materials, and are perfect for everyday use or travel.\r\n\r\nOrder yours now at 50% OFF with FREE Shipping: http://bangeshop.com\r\n\r\nBest Wishes,\r\n\r\nMandy', 0, '2026-09-11 15:01:09'),
(34, 'Keenan Royston', 'sales@aramiosmartglobal.com', '', 'Hey there \r\n\r\nLooking to improve your posture and live a healthier life? Our Medico Postura™ Body Posture Corrector is here to help!\r\n\r\nExperience instant posture improvement with Medico Postura™. This easy-to-use device can be worn anywhere, anytime – at home, work, or even while you sleep.\r\n\r\nMade from lightweight, breathable fabric, it ensures comfort all day long.\r\n\r\nGrab it today at a fantastic 60% OFF: https://medicopostura.com\r\n\r\nPlus, enjoy FREE shipping for today only!\r\n\r\nDon\'t miss out on this amazing deal. Get yours now and start transforming your posture!\r\n\r\nHave a great time, \r\n\r\nKeenan', 0, '2026-09-16 14:31:01'),
(35, 'Remont_lqEn', 'uwdkequlyEn@vseindi.com', '88681485388', '<a href=https://remont-dvig124.ru>Переборка двигателя</a> — профессиональный ремонт и диагностика двигателей автомобилей. \r\nБлагодаря этому можно установить источник поломки и подготовить точный план ремонта. \r\n \r\nЗатем специалисты измеряют компрессию и контролируют функционирование системы зажигания. \r\n \r\nПосле установки деталей специалисты проверяют зазоры и убеждаются в герметичности систем. \r\n \r\nПлавный режим работы способствует корректной притирке новых деталей.', 0, '2026-09-16 21:59:27'),
(36, 'Luella Dobbs', 'info@freeb2bdata.org', '4197896176', 'Hello,\r\n\r\nI am Luella Dobbs from FreeB2BData\r\n\r\nIt is with sad regret to inform you that we are shutting down\r\n\r\nWe have over 252 countries and over 33 million companies available in our database with phone numbers, industries, emails, etc.\r\n\r\nPlease come and download your data in the next 24 hours. \r\n\r\nhttps://Luella.freeb2bdata.org\r\n\r\nRegards,\r\nLuella Dobbs', 0, '2026-09-17 21:58:00'),
(37, 'Aman Katiyar', 'aman@rocketdigitaltech.com', '890112955', 'Hello http://aramiosmartglobal.com,\r\n\r\nI wanted to reach out to see if you’re open to exploring ways to grow your website traffic and boost online performance.\r\n\r\nWe offer customized SEO services that deliver measurable improvements.\r\n\r\nOnce you share your target keywords and target market, I’ll send a full proposal.\r\n\r\nBest Regards,\r\nAman', 0, '2026-09-19 15:49:34'),
(38, 'Berenice Steel', 'sales@aramiosmartglobal.com', '249107665', 'Hello \r\n\r\nI wanted to reach out and let you know about our new dog harness. It\'s really easy to put on and take off - in just 2 seconds - and it\'s personalized for each dog. \r\nPlus, we offer a lifetime warranty so you can be sure your pet is always safe and stylish.\r\n\r\nWe\'ve had a lot of success with it so far and I think your dog would love it. \r\n\r\nGet yours today with 50% OFF: https://caredogbest.com\r\n\r\nFREE Shipping - TODAY ONLY! \r\n\r\nBest regards, \r\n\r\nBerenice', 0, '2026-09-23 07:26:24'),
(39, 'Bill Hislop', 'info@freeb2bdata.org', '4353101', 'Hello,\r\n\r\nI am Bill Hislop from FreeB2BData\r\n\r\nIt is with sad regret to inform you that we are shutting down\r\n\r\nWe have over 252 countries and over 33 million companies available in our database with phone numbers, industries, emails, etc.\r\n\r\nPlease come and download your data in the next 24 hours. \r\n\r\nhttps://Bill.freeb2bdata.org\r\n\r\nRegards,\r\nBill Hislop', 0, '2026-09-24 16:19:39'),
(40, 'reyting_czsi', 'phzptqicusi@lilycake.ru', '88313448216', 'Если вы хотите выбрать качественное обучение, обязательно ознакомьтесь с <a href=https://vc.ru/education/3144210-chestnyy-reyting-kursov-po-seo>лучшие курсы seo</a>, чтобы найти оптимальные варианты. \r\nСегодня SEO считается неотъемлемой частью интернет-маркетинга.', 0, '2026-09-28 11:05:58'),
(41, 'Rashad Saunders', 'saunders.rashad@yahoo.com', '6765198227', '---cPanel, SSD, Softaculous, Fantastico, SiteBuilder, Free SSL...From $1/month\r\nCurrent 50% off Promotion For website Use Code: 50%wb at www.myskyhost.com\r\n---OpenVZ, KVM and Windows VPS, Solusvm Panel, SSD Drive...More From $7/month\r\nCurrent 10 off Promotion for VPS Use Code: vps10%off at www.myskyhost.com\r\n---RDP (Windows Remote Desktop) From $18/month\r\nCurrent 30% off Promotion For RDP Use Code: rdp30%off at www.myskyhost.com\r\n\r\nBest Wishes,\r\nMySkyHost.com | The Hosting Services.', 0, '2026-09-29 13:04:24'),
(42, 'Kelvin McFarland', 'sales@aramiosmartglobal.com', '961496176', 'Hey there, \r\n\r\nI hope you\'re doing well. I wanted to let you know about our new BANGE backpacks and sling bags that just released.\r\n\r\nBange is perfect for students, professionals and travelers. The backpacks and sling bags feature a built-in USB charging port, making it easy to charge your devices on the go.  Also they are waterproof and anti-theft design, making it ideal for carrying your valuables.\r\n\r\nBoth bags are made of durable and high-quality materials, and are perfect for everyday use or travel.\r\n\r\nOrder yours now at 50% OFF with FREE Shipping: http://bangeshop.com\r\n\r\nAll the best,\r\n\r\nKelvin', 0, '2026-10-01 00:55:35'),
(43, 'Jewell Kinsella', 'jewell@freeb2bdata.org', '686238628', 'Hi,\r\n\r\nYou probably noticed we went quiet.\r\n\r\nWe did shut down FreeB2BData — but it wasn\'t the end. We took it offline to rebuild it from scratch, much bigger and much better.\r\n\r\nThe new version is live.\r\n\r\nHere\'s what\'s inside:\r\n\r\n900 million people — names, job titles, companies, verified emails\r\n\r\n33 million companies — full business records with phones, emails, websites, and addresses\r\n\r\nAll data is live — always current, always fresh\r\n\r\nUnlimited exports — download as much as you want, whenever you want\r\n\r\nTo mark the relaunch, we\'re running a launch promo:\r\n\r\nLifetime access for just $50 — one-time payment, no subscription, no renewals, unlimited exports forever.\r\n\r\nBut it\'s strictly limited — only 20 seats left.\r\n\r\nClaim your lifetime seat here https://Jewell.freeb2bdata.org\r\n\r\n— The FreeB2BData Team', 0, '2026-10-03 18:09:46'),
(44, 'Michelle Kline', 'gemma.marshall112@gmail.com', '781528983', 'Hi,\r\n\r\nI came across aramiosmartglobal.com and thought your audience might love this. We’ve released a done-for-you training course about running Instagram Channels with AI.\r\n\r\nIt includes full private label rights, so you can rebrand the videos, guides, and sales pages, sell it as your own digital product, and keep 100% of the revenue.\r\n\r\nHere are the details if you want to take a look:\r\n\r\nhttps://instagrow.business\r\n\r\nBest,\r\nGemma', 0, '2026-10-04 02:51:29'),
(45, 'kalibrovka_imKl', 'ppmcttaamKl@atom77777.com', '84942548177', 'Для обеспечения точности измерений важно своевременно провести <a href=https://kalibrovka-kalibrov.ru/>калибровка гладких конических калибров</a>. \r\nБез своевременной калибровки калибров невозможно обеспечить высокое качество продукции.', 0, '2026-10-04 11:30:27'),
(46, 'kalibrovka_stKl', 'clwsbxzsiKl@atom77777.com', '85316298317', 'Для обеспечения точности измерений важно своевременно провести <a href=https://kalibrovka-kalibrov.ru/>Калибровка нестандартных калибров</a>. \r\nДокументирование позволяет отслеживать изменения и поддерживать качество измерений.', 0, '2026-10-06 08:49:18'),
(47, 'Fabian Stein', 'sales@aramiosmartglobal.com', '4135842050', 'Hi there \r\n\r\nLooking to improve your posture and live a healthier life? Our Medico Postura™ Body Posture Corrector is here to help!\r\n\r\nExperience instant posture improvement with Medico Postura™. This easy-to-use device can be worn anywhere, anytime – at home, work, or even while you sleep.\r\n\r\nMade from lightweight, breathable fabric, it ensures comfort all day long.\r\n\r\nGrab it today at a fantastic 60% OFF: https://medicopostura.com\r\n\r\nPlus, enjoy FREE shipping for today only!\r\n\r\nDon\'t miss out on this amazing deal. Get yours now and start transforming your posture!\r\n\r\nBest, \r\n\r\nFabian', 0, '2026-10-07 09:15:27'),
(48, 'MiguelEdups', 'u.v.u.v.u.n.ayoz0.0@gmail.com', '88573884776', 'Соблюдаем конфиденциальность, бережно общаемся с пациентом и его близкими на каждом этапе. \r\nОзнакомиться с деталями - https://narkologicheskaya-klinika-voronezh20.ru/', 0, '2026-10-07 23:18:26'),
(49, 'kalibrovka_njKl', 'nbwjowipxKl@atom77777.com', '88998439353', 'Для обеспечения точности измерений важно своевременно провести <a href=https://kalibrovka-kalibrov.ru/>Калибровка нестандартных калибров</a>. \r\nЭто помогает выявить возможные отклонения и принять необходимые меры.', 0, '2026-10-08 11:07:17'),
(50, 'Klaudia Chifley', 'chifley.klaudia87@outlook.com', '8405659921', '---cPanel, SSD, Softaculous, Fantastico, SiteBuilder, Free SSL...From $1/month\r\nCurrent 50% off Promotion For website Use Code: 50%wb at www.myskyhost.com\r\n---OpenVZ, KVM and Windows VPS, Solusvm Panel, SSD Drive...More From $7/month\r\nCurrent 10 off Promotion for VPS Use Code: vps10%off at www.myskyhost.com\r\n---RDP (Windows Remote Desktop) From $18/month\r\nCurrent 30% off Promotion For RDP Use Code: rdp30%off at www.myskyhost.com\r\n\r\nBest Wishes,\r\nMySkyHost.com | The Hosting Services', 0, '2026-10-08 16:09:29'),
(51, 'Philomena Veilleux', 'info@freeb2bdata.org', '697209604', 'Hi,\r\n\r\nQuick one — we just opened FreeB2BData, a B2B lead finder that gives you people, companies, emails and full outreach tools in one place. \r\n\r\nHere\'s what you get:\r\n\r\n������ People search — names, job titles, departments, LinkedIn profiles, verified emails\r\n������ Company search — phones, websites, addresses, industries, categories\r\n������ Powerful filters — country, state/province, city, industry, job title, website\r\n������ Unlimited CSV exports — take your leads anywhere\r\n������ Built-in email campaigns — send plain text or HTML, with live open/click tracking\r\n������ Data enrichment — we scan websites & databases to fill in missing emails and add new companies matching your filters\r\n������ 100,000 emails per month included from our servers.\r\n������ Live data updates — the database grows every day\r\n������ Affiliate program — earn 20% commission on every referral\r\n\r\n������ Claim your seat: https://freeb2bdata.org\r\n\r\nBonus: If you use RoboRep Dialer for cold calling, grab the Chrome extension — it pairs perfectly with the leads you pull from FreeB2BData:\r\n\r\n������ https://chromewebstore.google.com/detail/roborep-dialer/gfmifjmkopgfgafdejokdikldlmpejkl\r\n\r\nQuestions? Just reply to this email — I read every one.\r\n\r\nTalk soon,\r\nFreeB2BData', 0, '2026-10-09 18:55:28');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `training_type` enum('online','offline','online_live') NOT NULL DEFAULT 'online',
  `city` varchar(100) DEFAULT NULL,
  `venue_name` varchar(150) DEFAULT NULL,
  `map_link` text DEFAULT NULL,
  `live_link` varchar(255) DEFAULT NULL,
  `max_seats` int(11) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `live_time` time DEFAULT NULL,
  `title_ar` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `description_ar` text DEFAULT NULL,
  `description_en` text DEFAULT NULL,
  `price_usd` decimal(10,2) DEFAULT NULL,
  `price_dzd` decimal(10,2) DEFAULT NULL,
  `commission_type_usd` enum('percentage','fixed') DEFAULT NULL,
  `commission_value_usd` decimal(10,2) DEFAULT NULL,
  `commission_type_dzd` enum('percentage','fixed') DEFAULT NULL,
  `commission_value_dzd` decimal(10,2) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `status` enum('draft','pending','published','rejected') DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `trainer_id`, `category_id`, `training_type`, `city`, `venue_name`, `map_link`, `live_link`, `max_seats`, `start_date`, `live_time`, `title_ar`, `title_en`, `description_ar`, `description_en`, `price_usd`, `price_dzd`, `commission_type_usd`, `commission_value_usd`, `commission_type_dzd`, `commission_value_dzd`, `thumbnail`, `status`, `created_at`) VALUES
(1, 4, 1, 'offline', 'تونس', 'فندق الرمال', 'https://maps.app.goo.gl/JHbN43P1QDVNZ11D7', NULL, 30, '2026-03-31', NULL, 'ملتقى دولي', 'ملتقى دولي', 'ملتقى دولي في بلد تونس الشقيق', NULL, 100.00, 26000.00, 'fixed', 80.00, 'fixed', 20000.00, '1774424003_414.jpg', 'published', '2026-03-25 07:33:23'),
(2, 4, 1, 'online', NULL, NULL, NULL, NULL, 0, NULL, NULL, 'دورة برمجة العقل الباطني', 'دورة برمجة العقل الباطني', 'طريقة برمجة العقل الباطني', NULL, NULL, 15000.00, 'percentage', NULL, 'fixed', 5000.00, '1774527481_339.jpeg', 'published', '2026-03-26 12:18:01'),
(3, 4, 1, 'online_live', NULL, NULL, NULL, 'https://zoom.us/fr/signin', 20, '2026-04-01', '09:00:00', 'احتراف التسويق الالكتروني', 'احتراف التسويق الالكتروني', 'احتراف التسويق الالكتروني  و اعلانات الفايسبوك', NULL, NULL, 5000.00, 'percentage', NULL, 'fixed', 1000.00, '1774557034_962.jpeg', 'published', '2026-03-26 20:30:34'),
(4, 4, 1, 'online_live', NULL, NULL, NULL, 'https://zoom.us/fr/signin#/login', 10, '2026-03-26', '21:45:00', 'دورة ثاسث', 'دورة ثاسث', 'دورة ثاسث', NULL, 20.00, NULL, 'fixed', 10.00, 'percentage', NULL, '1774557745_167.jpeg', 'published', '2026-03-26 20:42:25');

-- --------------------------------------------------------

--
-- Table structure for table `course_orders`
--

CREATE TABLE `course_orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `amount_usd` decimal(10,2) DEFAULT NULL,
  `amount_dzd` decimal(10,2) DEFAULT NULL,
  `payment_method` enum('bank','paypal','agent') NOT NULL DEFAULT 'bank',
  `receipt_image` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected','reserved','canceled') DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_orders`
--

INSERT INTO `course_orders` (`id`, `user_id`, `course_id`, `amount_usd`, `amount_dzd`, `payment_method`, `receipt_image`, `status`, `admin_notes`, `created_at`) VALUES
(1, 5, 1, NULL, 26000.00, 'bank', '1774425183_8898.jpeg', 'approved', NULL, '2026-03-25 07:53:03'),
(2, 6, 1, 100.00, NULL, 'agent', '1774426595_8971.jpg', 'approved', NULL, '2026-03-25 08:16:35'),
(3, 5, 2, NULL, 15000.00, 'bank', '1774527595_4731.jpeg', 'approved', NULL, '2026-03-26 12:19:54'),
(4, 5, 3, NULL, 5000.00, 'bank', '1774557196_9843.jpeg', 'approved', NULL, '2026-03-26 20:33:16'),
(8, 6, 4, 20.00, NULL, 'bank', '1774619070_741.jpeg', 'approved', NULL, '2026-03-27 13:37:15'),
(9, 5, 4, 20.00, NULL, 'bank', '1774619676_955.jpeg', 'approved', NULL, '2026-03-27 13:54:20');

-- --------------------------------------------------------

--
-- Table structure for table `course_reviews`
--

CREATE TABLE `course_reviews` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `trainee_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `review_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_reviews`
--

INSERT INTO `course_reviews` (`id`, `course_id`, `trainee_id`, `rating`, `comment`, `review_image`, `created_at`) VALUES
(1, 1, 5, 5, 'ماشاء الله دورة ممتازة', NULL, '2026-03-26 15:10:15'),
(2, 4, 5, 5, 'ممتازة ماشاء الله استفدنا الكثير من الدورة كانت ممتعة', '1774620250_rev_155.jpeg', '2026-03-27 14:04:10');

-- --------------------------------------------------------

--
-- Table structure for table `custom_consultation_requests`
--

CREATE TABLE `custom_consultation_requests` (
  `id` int(11) NOT NULL,
  `trainee_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `trainee_problem` mediumtext NOT NULL,
  `status` enum('pending_trainer','accepted','rejected') DEFAULT 'pending_trainer',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` enum('usd','dzd') NOT NULL DEFAULT 'usd',
  `expense_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `title`, `amount`, `currency`, `expense_date`, `notes`, `created_at`) VALUES
(1, 'فايسبوك اعلان', 2000.00, 'dzd', '2026-03-25', NULL, '2026-03-25 07:54:39');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `image_type` enum('gallery','review') NOT NULL DEFAULT 'gallery',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `image_name`, `image_type`, `created_at`) VALUES
(18, '1775299222_133.png', 'review', '2026-04-04 10:40:22'),
(19, '1775299229_634.png', 'review', '2026-04-04 10:40:29'),
(20, '1775299235_102.png', 'review', '2026-04-04 10:40:35'),
(21, '1788739404_126.png', 'gallery', '2026-09-07 00:03:24');

-- --------------------------------------------------------

--
-- Table structure for table `legacy_certificates`
--

CREATE TABLE `legacy_certificates` (
  `id` int(11) NOT NULL,
  `certificate_code` varchar(50) NOT NULL,
  `student_name` varchar(150) NOT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `specialty` varchar(150) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `issue_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `legacy_certificates`
--

INSERT INTO `legacy_certificates` (`id`, `certificate_code`, `student_name`, `nationality`, `specialty`, `grade`, `issue_date`, `created_at`) VALUES
(1, 'IPD.310126', 'المبروك السيار', 'تونسي', 'خبير دولي معتمد في الطب البديل', 'ممتاز', '2026-01-31', '2026-04-04 22:44:52'),
(2, 'CIE.M.262626', 'خيرة حشايشي', 'جزائرية', 'خبير دولي معتمد في التجميل اللا جراحي', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(3, 'CIE.M.2603626', 'أمال حضري حميدة', 'جزائرية', 'خبير دولي معتمد في الاستدامة النفسية و في التعليم الهندسي والتدريب', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(4, 'CIE.M.268626', 'عائدة شويخة', 'تونسية', 'خبير دولي معتمد في التربية المختصة وتأهيل ذوي طيف التوحد', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(5, 'CIE.M.267626', 'ليلى شويخة', 'تونسية', 'خبير دولي معتمد في القيادة الإدارية والتمكين المهني', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(6, 'CIE.M.264626', 'رميلة نمديلي', 'جزائرية', 'خبير دولي معتمد في التجميل اللا جراحي', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(7, 'CIE.M.260626', 'عزيزة سالم', 'جزائرية', 'خبير دولي معتمد في الطب البديل', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(8, 'CIE.N.26626', 'أحلام بن ساسي', 'جزائرية', 'خبير دولي معتمد في التغذية العلاجية', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(9, 'CIE.M.266626', 'فضيلة موكاح', 'جزائرية', 'خبير دولي معتمد في التنمية الذاتية', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(10, 'CIE.M.263626', 'زوليخة لحسين', 'جزائرية', 'خبير دولي معتمد في الإرشاد النفسي والتطوير السلوكي', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(11, 'CIE.M.269626', 'مبارك حجاجي', 'جزائري', 'خبير دولي معتمد في الإرشاد والسياحة الدينية', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(12, 'CIE.M.2602626', 'أحمد قجالي', 'جزائري', 'خبير دولي معتمد في الإدارة المدرسية وتسيير المؤسسات التربوية', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(13, 'CIE.M.265626', 'زوبير سالم', 'جزائري', 'خبير دولي معتمد في التجارة العشبية والتغذية الطبيعية', 'ممتاز', '2026-06-26', '2026-07-03 00:04:08'),
(14, 'CIE.M.2600626', 'سهام بياتي', 'عراقية الجنسية', 'خبير دولي في مجال تطوير الذات والتنمية المستدامة', 'بدرجة ممتاز', '2026-06-26', '2026-07-27 16:56:37'),
(15, 'CIEx.70126', 'عبد الوهاب رايس', 'جزائري', 'خبير دولي معتمد في علم المكتبات: حوكمة المعلومات وأثرها على الأمن السيبراني', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(16, 'CIEx.30126', 'فاطمة الزهراء سحنون', 'جزائرية', 'خبير دولي معتمد في التدليك العلاجي والاسترخائي', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(17, 'CIEx.20126', 'مريم الوسلاتي', 'تونسية', 'خبير دولي معتمد في الطب البديل التكاملي', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(18, 'CIEx.40126', 'سلوى الشوّالي', 'تونسية', 'خبير دولي معتمد في الرقية الشرعية المطورة المتكاملة', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(19, 'CIEx.60126', 'شاذلية خرشوفي', 'تونسية', 'خبير دولي معتمد في العلاج بالطاقة الحيوية', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(20, 'CIE.23111725', 'حيمر سعاد', 'جزائرية', 'خبير دولي معتمد في التغذية العلاجية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:28'),
(21, 'CIEx.80126', 'عائشة فارح', 'جزائرية', 'خبير دولي معتمد في القانون العام للأعمال', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(22, 'CIEx.90126', 'سعيدة مسعودي', 'جزائرية', 'خبير دولي معتمد في الطب التكميلي والتجميل اللاجراحي', 'ممتاز', '2026-01-27', '2026-07-28 20:58:28'),
(23, 'PD.114825', 'نورة تبة', 'جزائرية', 'دبلوم مهني في مربية طفولة مبكرة', 'ممتاز', '2025-08-14', '2026-07-28 20:58:56'),
(24, 'PD.1142825', 'بوناب بشرى', 'جزائرية', 'دبلوم مهني في مربية طفولة مبكرة', 'ممتاز', '2025-08-14', '2026-07-28 20:58:56'),
(25, 'CIE.2311125', 'سالم كور جميلة', 'جزائرية', 'خبير دولي معتمد في التغذية الصحية والعلاجات الطبيعية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(26, 'Dr.107825', 'عبد المالك طاهر', 'جزائري', 'دكتوراه مهنية في الطب الصيني والطب التكميلي-التجميلي اللا-جراحي', 'ممتاز', '2025-08-07', '2026-07-28 20:58:56'),
(27, 'CIE.2311725', 'بوفناية صبرينة', 'جزائرية', 'خبير دولي معتمد في العلاج الإنعكاسي والطب البديل', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(28, 'CIE.2311425', 'بن الشيخ نعناعة', 'جزائرية', 'خبير دولي معتمد في التدريب في التنمية البشرية والعلاجات الطبيعية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(29, 'CIE.2311925', 'عزيزة جابر', 'جزائرية', 'خبير دولي معتمد في العلاج بالأعشاب الطبية والطب البديل', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(30, 'CIE.2311825', 'الهادي التميمي', 'تونسي', 'خبير دولي معتمد في الدراسات القرآنية المعاصرة وتصميم برامج التمكين التربوي المستدام', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(31, 'CIE.2311625', 'سليماني اويس', 'جزائري', 'خبير دولي معتمد في المعلوماتية والذكاء الإصطناعي', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(32, 'CIE.23111425', 'فاطمة الزهراء بن مرابط', 'جزائرية', 'خبير دولي معتمد في التجميل اللاجراحي والطب البديل', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(33, 'CIE.2311325', 'عواطف بكاكرة', 'جزائرية', 'خبير دولي معتمد في ريادة الأعمال والتنمية المستدامة', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(34, 'CIE.2311225', 'تراكة فطيمة', 'جزائرية', 'خبير دولي معتمد في الطاقة الحيوية والعلاجات الطبيعية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(35, 'CIE.23111525', 'عايشة قحيوش', 'جزائرية', 'خبير دولي معتمد في الطب البديل والعلاجات الطبيعية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(36, 'CIE.23111625', 'علي عبيد', 'تونسي', 'خبير دولي معتمد في الهندسة الميكانيكية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56'),
(37, 'CIE.126825', 'مريم الوسلاتي', 'تونسية', 'خبير دولي معتمد في تقويم الأعضاء والتأهيل الوظيفي', 'ممتاز', '2025-08-26', '2026-07-28 20:58:56'),
(38, 'IPD.181225', 'مدكور راضية', 'جزائرية', 'دبلوم مهني في المعجنات والحلويات التقليدية والعصرية', 'ممتاز', '2025-12-08', '2026-07-28 20:58:56'),
(39, 'CIE.23111225', 'قيس الجنزري', 'تونسي', 'خبير دولي معتمد في الفنون البصرية', 'ممتاز', '2025-11-23', '2026-07-28 20:58:56');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title_ar` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `lesson_order` int(11) DEFAULT 0,
  `is_free` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `course_id`, `title_ar`, `title_en`, `video_url`, `lesson_order`, `is_free`, `created_at`) VALUES
(1, 2, '1', '1', 'https://www.youtube.com/', 1, 1, '2026-03-26 13:24:16');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_completions`
--

CREATE TABLE `lesson_completions` (
  `trainee_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lesson_completions`
--

INSERT INTO `lesson_completions` (`trainee_id`, `lesson_id`) VALUES
(5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `live_events_leads`
--

CREATE TABLE `live_events_leads` (
  `id` int(11) NOT NULL,
  `event_name` varchar(150) NOT NULL,
  `full_name_ar` varchar(150) NOT NULL,
  `full_name_en` varchar(150) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(50) NOT NULL,
  `whatsapp` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) DEFAULT NULL,
  `municipality` varchar(150) DEFAULT NULL,
  `research_title` mediumtext NOT NULL,
  `marketer_code` varchar(50) DEFAULT 'direct',
  `status` enum('new','contacted','paid','canceled') DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `live_events_leads`
--

INSERT INTO `live_events_leads` (`id`, `event_name`, `full_name_ar`, `full_name_en`, `dob`, `phone`, `whatsapp`, `country`, `state`, `municipality`, `research_title`, `marketer_code`, `status`, `created_at`) VALUES
(5, 'ملتقى ماليزيا الدولي 2026', 'نورالدين بلعميري', '', '1984-04-18', '0666568749', '0666568749', 'الجزائر', '', '', 'التامين', 'yassine', 'contacted', '2026-05-03 13:14:50'),
(6, 'ملتقى ماليزيا الدولي 2026', 'سمية بوطريق', '', '1997-03-22', '+213557859705', '+213557859705', 'الجزائر', '', '', 'فلسفة سياسية', 'yassine', 'contacted', '2026-05-03 17:54:55'),
(7, 'ملتقى ماليزيا الدولي 2026', 'Meriem Souici', '', '2000-01-24', '0699724810', '213699724810', 'الجزائر', '', '', 'ماستر لغة عربية ودراسات قرآنية المشاركة بورقة بحثية', 'yassine', 'contacted', '2026-05-03 19:41:11'),
(8, 'ملتقى ماليزيا الدولي 2026', 'عبد الحميد أحمد', '', '1992-01-13', '660563037', '660563037', 'الجزائر', '', '', 'مدربة تنمية البشرية', 'yassine', 'contacted', '2026-05-03 20:45:36'),
(9, 'ملتقى ماليزيا الدولي 2026', 'سماش مختارية', '', '1980-02-09', '0796856086', '0796856086', 'الجزائر', '', '', 'أشارك بورقة بحثية', 'yassine', 'new', '2026-05-04 11:11:09'),
(10, 'ملتقى ماليزيا الدولي 2026', 'keddar meriem', '', '2026-11-20', '00213669737670', '00213669737670', 'الجزائر', '', '', 'باحثة في التخطيط اللغوي', 'sabira', 'new', '2026-05-04 15:07:31'),
(11, 'ملتقى ماليزيا الدولي 2026', 'رزان', '', '1974-05-26', '0666588275', '0671848288', 'الجزائر', '', '', 'مدرب تنمية بشرية', 'yassine', 'new', '2026-05-05 11:49:23');

-- --------------------------------------------------------

--
-- Table structure for table `popup_notifications`
--

CREATE TABLE `popup_notifications` (
  `id` int(11) NOT NULL,
  `message_ar` varchar(255) NOT NULL,
  `message_en` varchar(255) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `popup_notifications`
--

INSERT INTO `popup_notifications` (`id`, `message_ar`, `message_en`, `status`, `created_at`) VALUES
(1, 'سجل محمد عمراني في دورة تطوير الذات', 'Mohammed Omrani registered for the self-development course', 1, '2026-03-25 07:10:59'),
(2, 'تم تقييم دورة برمجة العقل الباطني من طرف المتدرب برغوم هلال ب 5 نجوم ', 'The subconscious mind programming course was rated 5 stars by trainee Barghoum Hilal.', 1, '2026-03-26 15:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value_ar` text DEFAULT NULL,
  `setting_value_en` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value_ar`, `setting_value_en`) VALUES
(1, 'site_name', 'أكاديمية أراميـــو سمـــارت العـالميـــة', 'Aramio Smart Global Academy'),
(2, 'contact_email', 'contact@aramiosmartglobal.com', 'info@aramio.com'),
(3, 'phone_number', '00213698006662', '+1234567890'),
(4, 'about_us', 'نحن أكاديمية رائدة...', 'We are a leading academy...'),
(5, 'promo_title', 'الملتقى الدولي القادم ', NULL),
(6, 'promo_subtitle', 'إكتشف الأن مكان  الملتقى القادم المقاعد محدودة سارعوا بالحجز', NULL),
(7, 'promo_end_date', '2026-09-11T23:59:59', NULL),
(8, 'promo_link', '', NULL),
(12, 'facebook_link', 'https://www.facebook.com/share/16tSBhW7UM/', NULL),
(13, 'twitter_link', 'https://wazirtdawl.xo.je/aramia', NULL),
(14, 'instagram_link', 'https://www.instagram.com/aramio_smart_global_academy?igsh=MXN0MjhvYnAxeWxqcg==', NULL),
(29, 'stat_courses', '60', NULL),
(30, 'stat_students', '320', NULL),
(31, 'stat_trainers', '17', NULL),
(63, 'bank_details', '\r\n<div class=\"text-end\" dir=\"rtl\">\r\n    <strong class=\"text-primary d-block mb-2\">الدفع عبر الحساب البريدي الجاري (CCP):</strong>\r\n    <span class=\"d-block\">الاسم: <strong>HARKAT SABIRA</strong></span>\r\n    <span class=\"d-block\">الحساب: <strong>0004824566 clé 72</strong></span>\r\n    <span class=\"d-block mb-3\">المركز: <strong>قسنطينة</strong></span>\r\n    \r\n    <strong class=\"text-success d-block mb-2\">الدفع عبر بريدي موب (RIP):</strong>\r\n    <span class=\"d-block font-monospace text-start fs-6 fw-bold\">00799999000482456672</span>\r\n</div>\r\n', NULL),
(64, 'paypal_email', 'payments@aramio.com', NULL),
(65, 'agent_details', 'وكيل الجزائر العاصمة: 0555000000<br>وكيل وهران: 0666000000', NULL),
(73, 'promo_title_en', 'International Forum of International Experts', NULL),
(74, 'promo_subtitle_en', 'Limited Seats, Book Now!', NULL),
(75, 'promo_link_en', '', NULL),
(76, 'exchange_rate', '255', NULL),
(77, 'stat_consultations', '260', NULL),
(237, 'popup_timer', '50', NULL),
(256, 'youtube_link', 'https://youtube.com/@dr.sabiraharket1412?si=l2RlLC0Y2arbwRmV', NULL),
(467, 'msg_course_approved', 'تم قبول دورتك و نشرها في الموقع بالتوفيق', NULL),
(468, 'msg_order_approved', 'تم تفعيل بنجاح', NULL),
(469, 'msg_order_rejected', 'تم رفض إيصال ', NULL),
(470, 'msg_trainer_paid', 'تم تحويل الأرباح بنجاح ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `statistics`
--

CREATE TABLE `statistics` (
  `id` int(11) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `title_ar` varchar(100) NOT NULL,
  `count_number` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statistics`
--

INSERT INTO `statistics` (`id`, `icon`, `title_ar`, `count_number`, `created_at`) VALUES
(2, 'fa-users', 'الطلاب المسجلين', 282673, '2026-03-18 09:38:32'),
(3, 'fa-bell', 'الفصول المكتملة', 11223, '2026-03-18 09:38:32'),
(4, 'fa-earth-americas', 'المتابعين الأجانب', 94532, '2026-03-18 09:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `feedback_text` text NOT NULL,
  `rating` int(11) DEFAULT 5,
  `status` tinyint(1) DEFAULT 1,
  `image` varchar(255) DEFAULT 'default_avatar.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trainer_availabilities`
--

CREATE TABLE `trainer_availabilities` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `consult_type` enum('family','self_dev','personal','other') NOT NULL DEFAULT 'personal',
  `session_mode` enum('online','offline') NOT NULL DEFAULT 'online',
  `city` varchar(100) DEFAULT NULL,
  `venue_name` varchar(150) DEFAULT NULL,
  `map_link` text DEFAULT NULL,
  `available_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `slot_code` varchar(20) DEFAULT NULL,
  `price_usd` decimal(10,2) DEFAULT NULL,
  `price_dzd` decimal(10,2) DEFAULT NULL,
  `is_booked` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trainer_availabilities`
--

INSERT INTO `trainer_availabilities` (`id`, `trainer_id`, `consult_type`, `session_mode`, `city`, `venue_name`, `map_link`, `available_date`, `start_time`, `end_time`, `slot_code`, `price_usd`, `price_dzd`, `is_booked`, `created_at`) VALUES
(1, 4, 'personal', 'online', NULL, NULL, NULL, '2026-03-28', '09:00:00', '00:00:00', 'AR-C9634', NULL, 1000.00, 0, '2026-03-26 13:21:34'),
(2, 4, 'personal', 'online', NULL, NULL, NULL, '2026-03-27', '09:00:00', '12:00:00', 'AR-0699C63', NULL, 5000.00, 1, '2026-03-26 21:04:00'),
(3, 4, 'personal', 'online', NULL, NULL, NULL, '2026-03-27', '09:00:00', '12:00:00', 'AR-C1880', NULL, 2000.00, 0, '2026-03-26 22:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `trainer_earnings`
--

CREATE TABLE `trainer_earnings` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` enum('usd','dzd') NOT NULL DEFAULT 'usd',
  `is_paid` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trainer_earnings`
--

INSERT INTO `trainer_earnings` (`id`, `trainer_id`, `order_id`, `amount`, `currency`, `is_paid`, `created_at`) VALUES
(1, 4, 1, 20000.00, 'dzd', 1, '2026-03-25 07:53:48'),
(2, 4, 2, 80.00, 'usd', 1, '2026-03-25 08:17:34'),
(3, 4, 3, 10000.00, 'dzd', 1, '2026-03-26 13:02:31'),
(4, 4, 3, 10000.00, 'dzd', 1, '2026-03-26 13:06:34'),
(5, 4, 4, 3500.00, 'dzd', 1, '2026-03-26 20:43:09'),
(6, 4, 8, 15.00, 'usd', 1, '2026-03-27 13:45:08'),
(7, 4, 9, 10.00, 'usd', 1, '2026-03-27 13:55:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `whatsapp_number` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `verification_code` varchar(10) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `avatar` varchar(255) DEFAULT 'default_avatar.png',
  `role` enum('admin','staff','trainer','trainee') DEFAULT 'trainee',
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `last_name`, `email`, `password`, `phone`, `whatsapp_number`, `country`, `bio`, `verification_code`, `is_verified`, `avatar`, `role`, `status`, `created_at`) VALUES
(3, 'المدير العام', NULL, 'admin@aramio.com', '$2y$10$RDdcZGtseS4Ok/mSPsDcCeZk9zvbqemYL0VVr9pQLq8RAdWUtgkSa', NULL, NULL, NULL, NULL, NULL, 0, 'default_avatar.png', 'admin', 1, '2026-03-25 07:04:56'),
(4, 'صبيرة حركات', NULL, 's@gmail.com', '$2y$10$BG5UN8D5gd3NME2TF28a5ePp1lvrfrqD4QMxkb0ezgYwr6.9JYWy2', '', '0021350515253', 'الجزائر', 'مدربة مدربين دولية', NULL, 1, '1774526072_4.jpg', 'trainer', 1, '2026-03-25 07:05:54'),
(5, 'برغوم هلال', 'هلال', 'hberghoum@gmail.com', '$2y$10$1.VC/ktJxE1BEEAmta/E9.kOwOPl7McrvZIxcBKhuw9AdQml0ObMu', '', '0663885544', '', NULL, NULL, 1, '1774525939_5.png', 'trainee', 1, '2026-03-25 07:06:46'),
(6, 'فادي برغوم', 'برغوم', 'fadiberghoum@gmail.com', '$2y$10$UGW8S0OWjv41HuYtlPEeIu9htxjI9sMXi6zOhY4xYk4eYgDbpxxgq', '+213775255465', NULL, 'الجزائر', NULL, NULL, 1, '1774426562_6.png', 'trainee', 1, '2026-03-25 08:12:11'),
(7, 'ياسين', 'ياسين', 'yassine@gmail.com', '$2y$12$D3NSR6/yrV/7ijWkKmMznu56jhbmtEtjQmvMq5qnPE0K5L3G3ABEG', '0663883435', '+213556236589', 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainee', 1, '2026-09-17 20:01:43'),
(8, 'أحلام بن ساسي', NULL, 'ahlam@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(9, 'أمال حضري حميدة', NULL, 'amal@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(10, 'ليلى شويخة', NULL, 'laila@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'تونس', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(11, 'عائدة شويخة', NULL, 'aida@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'تونس', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(12, 'زوليخة لحسين', NULL, 'zoulikha@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(13, 'مبارك حجاجي', NULL, 'mubarak@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(14, 'مبروك السيار', NULL, 'mabrouk@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'تونس', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(15, 'فضيلة موكاح', NULL, 'fadhila@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(16, 'زوبير سالم', NULL, 'zoubir@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(17, 'رميلة نمديلي', NULL, 'romaila@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(18, 'خيرة حشايشي', NULL, 'khaira@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24'),
(19, 'عزيزة سالم', NULL, 'aziza@aramiosmartglobal.com', '$2y$12$zZ9rm1Le4DQZ8HCQ5buAfu027SNJfj9WdKWlmWt8FDGkzlQ20mLJO', NULL, NULL, 'الجزائر', NULL, NULL, 1, 'default_avatar.png', 'trainer', 1, '2026-09-24 17:49:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `certificate_code` (`certificate_code`);

--
-- Indexes for table `certificate_exams`
--
ALTER TABLE `certificate_exams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `certificate_code` (`certificate_code`);

--
-- Indexes for table `consultation_bookings`
--
ALTER TABLE `consultation_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_orders`
--
ALTER TABLE `course_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_reviews`
--
ALTER TABLE `course_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_consultation_requests`
--
ALTER TABLE `custom_consultation_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `legacy_certificates`
--
ALTER TABLE `legacy_certificates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `certificate_code` (`certificate_code`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lesson_completions`
--
ALTER TABLE `lesson_completions`
  ADD PRIMARY KEY (`trainee_id`,`lesson_id`);

--
-- Indexes for table `live_events_leads`
--
ALTER TABLE `live_events_leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `popup_notifications`
--
ALTER TABLE `popup_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `statistics`
--
ALTER TABLE `statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trainer_availabilities`
--
ALTER TABLE `trainer_availabilities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slot_code` (`slot_code`);

--
-- Indexes for table `trainer_earnings`
--
ALTER TABLE `trainer_earnings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `certificate_exams`
--
ALTER TABLE `certificate_exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `consultation_bookings`
--
ALTER TABLE `consultation_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course_orders`
--
ALTER TABLE `course_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `course_reviews`
--
ALTER TABLE `course_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `custom_consultation_requests`
--
ALTER TABLE `custom_consultation_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `legacy_certificates`
--
ALTER TABLE `legacy_certificates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `live_events_leads`
--
ALTER TABLE `live_events_leads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `popup_notifications`
--
ALTER TABLE `popup_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=494;

--
-- AUTO_INCREMENT for table `statistics`
--
ALTER TABLE `statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trainer_availabilities`
--
ALTER TABLE `trainer_availabilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `trainer_earnings`
--
ALTER TABLE `trainer_earnings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
